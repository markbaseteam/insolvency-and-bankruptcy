---

embedded-title: false
banner_icon: 📚

---
# IBC summary
1. [[Parts I and II of IBC]]
2. [[Part III IBC]]


