---
tags: [ ibc ]
cssclass:  noyaml
up:: [[📚 IBC Repository]]
---

```toc
```


# Part III IBC
![[Part III IBC - Overview.png]]



### Overview
- Part III applies to **matters** relating to **==fresh start, insolvency==**, and ==**bankruptcy**== of **==individuals and partnerhsip firms==** where the **amount of default** is **<u>not less than 1000 rupees</u>** - <mark style="background: #00FFFE73;">s78</mark> 


---

### Important Definitions for Part III


#### Adjudicating authority
<mark style="background: #00FFFE73;">Section 78</mark> 
- In this case, it is the **==debt recovery tribunal==** constituted under **subsection 1 of s3 of the Recovery of Debts Due to Financial Institutions Act of 1993**


<br>

<br>


#### Associate of debtor
<mark style="background: #00FFFE73;">section 79(2)</mark> 
1. person who belongs to **immediate family**
2. person who is a **<u>relative</u> fo the debtor** or a **relative of the spouse of the debtor**
3. person who is **in partnership with the debtor**
4. person who is a **spouse or a relative of any person with whom the debtor is in partnership**
5. person who is **employer of the debtor** or **employee of the debtor**
6. (f) a person who is a **trustee of a trust in which** the ==**beneficiaries of the trust include a debtor,**== or the terms of the trust confer a power on the trustee which may be exercised for the benefit of the debtor; and
7. (g) a **company**, **==where the debtor or the debtor along with his associates, own more than fifty per cent. of the share capital of the company==** or ==**control the appointment of the board of directors of the company.**==

##### Who is a relative?
- <mark style="background: #00FFFE73;">Explanation</mark>  relative if
	1. members of **Hindu Undivided family**
	2. one person is **rleated to the other in such manner as prescribed**

<br>


<br>

#### Bankrupt
<mark style="background: #00FFFE73;">Section 79(3)</mark> 
1. a debtor who has been **adjudged as bankrupt** by a ==**bankruptcy order**== under <mark style="background: #00FFFE73;">Section 126</mark> 
2. where a **==bankruptcy order==** has been made under section 126 -> **==each of the partners of a firm==**
3. any person ==**adjudged as insolvent**==

<br>

#### Bankruptcy 
- The state of being bankrupt

<br>


#### Banckruptcy debt
<mark style="background: #00FFFE73;">79(5)</mark>  
1. Any debt owed by a **bankrupt** as on the **bankruptcy commencement date** ;
2. any debt for which **the bankrupt** may **become liable** ==**after bankruptcy commencment date**== but **before his discharge by reason of any transaction entered into before the bankruptcy commencement date**
3. Any interest **part of the debt** under *<mark style="background: #00FFFE73;">Section 171</mark> *


<br>

#### Bankruptcy commencement date 
<mark style="background: #00FFFE73;">79(6)</mark>  
- Date on which a **bankruptcy order is passed by the AA** under **section 126** 


<br>

#### Bankruptcy order
- <mark style="background: #00FFFE73;">79(7)</mark>   **order** passed under *<mark style="background: #00FFFE73;">Section 126</mark> *


<br>

#### Bankruptcy process:
- Process under Chapters IV and IV of this Part

<br>

#### “bankruptcy trustee” 
means the **==insolvency professional appointed as a trustee for the estate ofthe bankrupt under section 125;==**

<br>


#### Committee of Creditors
<mark style="background: #00FFFE73;">79(11)</mark> 
- Committe of creditors constituted under <mark style="background: #00FFFE73;">Section 134</mark> 


<br>

#### Discharge Order 
<mark style="background: #00FFFE73;">section 79(13)</mark> 
- Order ==**passed by the adjudicating authority**==

<br>

#### Excluded assets - s79(14)
- (a) **unencumbered tools, books, vehicles** and **other equipmen**t as are ==**necessary**== to the debtor or bankrupt for his **==personal use or for the purpose of his employment, business or vocation,==**
- (b) **unencumbered furniture**, **==household equipment==** and provisions as are ==**necessary for satisfying the basic domestic needs of the bankrupt and his immediate family**==;
- (c) any unencumbered personal ornaments of such value, as may be prescribed, of the debtor or his immediate family which cannot be parted with, in accordance with religious usage;
- (d) any unencumbered life insurance policy or pension plan taken in the name of debtor or his immediate family; and
- (e) an unencumbered single dwelling unit owned by the debtor of such value as may be prescribed;

<br>

#### Excluded debt:
<mark style="background: #00FFFE73;">section 79(15)</mark> 
- It means
	1. (a) liability to pay fine imposed by a court or tribunal;
	2. (b) liability to pay damages for negligence, nuisance or breach of a statutory, contractual or other legal obligation;
	3. (c) liability to pay maintenance to any person under any law for the time being in force;
	4. (d) liability in relation to a student loan; and
	5. (e) any other debt as may be prescribed;

<br>

#### Firm
<mark style="background: #00FFFE73;">Section 79(16)</mark> 
- **body of individuals** carrying on **business ==in partnership==** -> **<u>whether nor not registered</u>** under s69 of <mark style="background: #00FFFE73;">partnerhsip Act, 1932</mark> 

<br>

#### Immediate family:
- Spouse, dependent children, dependent parents

<br>

#### Partnerhsip debt:
- Debt for which **all the partners in the firm** are **==jointly liable==**

<br>

#### Qualifying debt - s79(19)
- amount due; which **includes interest or any other sum due** in respect of the **amounts owed under any contract** by the debtor for a **liquidated sum** either **immediately or at certain future time**
- It does not include
	1. [[#Excluded debt]]
	2. debt to the extent **it is secured** -> [[secured interest]]
	3. any **debt** which has **been incurred three months prior to the ==date of the application for fresh start process==**

<br>

#### Repayment Plan
- plan prepared **==by the debtor in consultation with the resolution professional==** under section 105 **<u>containing a proposal to the committee of creditors for restructuring of his debts or affairs</u>**;

![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan#Preparation of Repayment plan during the moratorium period]]

<br>


#### Resolution professional
- insolvency professional appointed under this part as a resolution professional for conducting the fresh start process or insolvency resolution process;

<br>


#### Undischarged bankrupt
- "undischarged bankrupt" means a bankrupt who **<mark style="background: #FF5582A6;">has not received a discharge order under section 138.</mark> **

<br>

----
### Ch 2: Fresh Start Process

>Once an eligible person makes an application to the Debt Recovery Tribunal (DRT) and the application gets accepted, **==they are discharged from the qualifying debts and are not required to pay such debts.==**  
  
[[Fresh Start Process.png]]
![[Fresh Start Process.png]]
<br>



#### Who can apply for fresh start process?  s80
- ***==ONLY A DEBTOR==***, who is ==unable to pay his debt and fulfills the below specified conditions== shall be entitled to make an application for a fresh start for discharge of his qualifying debt under this Chapter. A debtor may apply, either ==**personally**== or ==**through a resolution professional**==, for a fresh start under this Chapter in respect of his qualifying debts to the Adjudicating Authority if --
	1. (a) the **gross annual income of the debtor does not exceed sixty thousand rupees;**
	2. (b) the **aggregate value of the assets of the debtor does not exceed twenty thousand rupees;**
	3. (c) the **aggregate value of the qualifying debts does not exceed thirty-five thousand rupees;**
	4. (d) he is **not an undischarged bankrupt;**
	5. (e) he does not own a dwelling unit, irrespective of whether it is encumbered or not;
	6. (f) a fresh start process, insolvency resolution process or bankruptcy process is not subsisting against him; and
	7. (g) no previous fresh start order under this Chapter has been made in relation to him in the preceding twelve months of the date of the application for fresh start. (SECTION 80)

#### Interim moratorium period s81
- After ==**application**== is filed under **Section 80**, then an ==**INTERIM MORATORIUM PERIOD COMMENCES**== from **<u>the date of filing</u>**; the moratorium **commences with respect to all the debts**
	- it **ceases to have effect on** the ==**date of admission or rejection of the application**==

#### Resolution professional s82
- If the application under section 80 is filed **by the debtor ==through a Resolution professional==**, the AA ==shall **direct the Board**== <mark style="background: #00FF3E8C;">**within 7 days of the receitp fo the application**</mark>  and ==**seek confirmation from the board that there are *no disciplinary proceedings* against the RP**== who has submitted the application
- If the application is **not made through RP** 🔴 , then the **Adjudicating authority** shall **==direct the board==** **within ==7days of receipt of application==** to **==nominate a resolution prof for the fresh start process==**

##### Duration within which RProfessional should examine the application under s80?
- ==**Within 10 days of his appointment**== -<mark style="background: #00FFFE73;"> Section 83</mark> 
##### Contents of report: s83
1. **[[#Qualifying debt - s79 19]]**
2. **liabilities** that are **==eligible for discharge under subsection (3)  of s92==** ![[Part III IBC.png]]

##### Can the Resolution professional call for further info or explanation in connection with application? s83(3)
- Yes, he may call for such further info from
	1. the **debtor**, or 
	2. **any other person** who in his opinion **may provide such info**
###### Duration for furnishing such info?
- ==**7 days**==

<br>

##### When shall the Resolution professional presume that the debtor is unable to pay his debts? 🟢 s83
- if
	1. in **in his opinion**, the **info supp.lied ==indicates that the debtor is unable to pay his debts==** if the RP has **no reason to believe that the info supplied is incorrect/incomplete**
	2. he has **reason to believe** that there is **==no change in the financial circumstances of the debtor==** ==since the **date of application**== that **would enable the debtor to pay his debts**

##### When shall the Resolution Professional REJECT THE APPLICATION? 🔴
- IF IN HIS opinion:
	1. debtor **does not satisfy the conditions** laid down in section 80 -> [[#Who can apply for fresh start process s80]]
	2. the debts that are disclosed in the application are **not [[#Qualifying debt - s79 19|qualifying debts]]** 🔴
	3. the debtor has ==**deliberately**== made a ==**false representation or omission in the application**== or wrt the ==**documents or information submitted**==

>- After this, the RP **records reasons for acceptance/rejection of application** and sends the the report to the [[#Adjudicating authority]]

<br>


#### Decision of AA wrt application  - Section 84
- AA will ==**admit or reject the application**==
##### Duration for decision?
- **==14 days==**
##### What should the order passed by the AA state?
- It should state the **==amount which has been accepted as [[#Qualifying debt - s79 19|qualifying debt]] under the Resolution professional==** and other amounts eligible for discharge under **s92** for the purposes of the fresh start order
##### Can this  oder be revoked? section 91 🔴🔴🔴🔴🔴 
- Yes
	- the RP may **submit an application to the AA** for revocation on the following grounds
		- if due to ==any change in the financial circumstances of the debtor, the debtor is ineligible for a fresh start process==; or 
		- non-compliance by the debtor of the restrictions imposed under section 85(3) [[#^782e82|see here]]; or 
		- if the **debtor has acted in a ==mala fide== manner and has willfully failed to comply with the provisions of this Chapter.**
###### Duration for deciding application? 
- within 14 days of receipt fo application
###### If admitted?
- the **moratorium and fresh start process will ==cease to have effect==**


<br>

#### What happens upon admission of application? - s85
##### Moratorium period
- During the period:
	1. any **==pending legal action or legal proceeding in respect of any debt shall be deemed to have been stayed==**; and
	2. subject to the provisions of section 86, the ==**creditors shall not initiate any legal action or proceedings in respect of any debt.**==
	- the debtor shall-- ^782e82
		1. (a) **not act as a director of any company, or directly or indirectly take part in or be concerned in the promotion, formation or management of a company;**
		2. (b) n**ot dispose of or alienate any of his asset**s;
		3. (c) **inform his business partners that he is undergoing a fresh start** process;
		4. (d) be re**quired to inform prior to entering into any financial or commercial transaction of such value as may be notified by the Central Government, either individually or jointly, that he is undergoing a fresh start process;**
		5. (e) d**isclose the name under which he enters into business transactions, if it is different from the name in the application admitted under section 84;**
		6. (f) n==**ot travel outside India except with the permission of the Adjudicatin**==g Authority.

##### When does the moratorium cease to have effect?
- end of ==**180 days**== beginning w/ the **date of admission**, unless the order admitting the application is **revoked under s91** -> [[#Can this oder be revoked section 91 🔴🔴🔴🔴🔴||see here]]

<br>

#### Can the creditor to whom a qualifying debt is owed object to the order under s84 by the AA?
- Yes
##### On what grounds?
- Only on
	1. **inclusion of a debt** as a **[[#Qualifying debt - s79 19]]**
	2. **incorrectness fo the details of the [[#Qualifying debt - s79 19]]** specified in the **oreder under s84 by the AA**

##### Can the creditor file objection under 86(1) by way of application to Resolution Professional?
- Yes; and the RP **shall consider every objection made under this section**
	- RP -> shall examine objections and ==**either accept or reject the objections**== -> within ***10 days of the date of application***
	- RP can also examine any matter that acc to him appears to be relevant when making a final list of qualifying debts for the purposes of <mark style="background: #00FFFE73;">Section 92(discharge order)</mark> 
- On the **basis of this examination**, the **RP shall 
	1. **amend** the list **of** qualifying debts for the purpose of the discharge order
	2. ==**make an application to the AA for directions under s90**==
	3. take such other steps as he considers necessary in r/lation to the debtor


<br>

#### Can n application be made against decision of Resolution professional? Section 87
- Yes; 
##### Who can institute such application?
1. **The debtor**, or
2. **the creditor**
##### What are the grounds for challenge?
- All or any of the following
	1. the resolution prof has **==not given opportunity to the debtor or creditor to make a representation==**
	2. the RP ==**colluded with the other party**== when arriving at the decision
	3. the RP has ==**not complied with requirements of s86**==

##### Duration w/in which AA should decide the application
- **==14 days==** 
- The AA will **==forward the application to the Board==** and the **board may take such action as may be required under Ch VI** of Part IV


<br>

#### What are the General duties of debtor? s88
- debtor shall 
	- make available to the resolution professional all information relating to his affairs, attend meetings and comply with the requests of the resolution professional in relation to the fresh start process. 
	- Inform the resolution professional as soon as reasonably possible of--
		1. (i) any material error or omission in relation to the information or document supplied to the resolution professional; or
		2. (ii) any change in financial circumstances after the date of application, where such change has an impact on the fresh start process.

<br>

#### Can resolution professional be replaced?
- Yes, where the ==**debtor or creditor is of the opinion**== that the ==**RP appointed under s82 is required to be replaced**==, they may **apply to the AA**
	- AA will ==**make reference to the board**== within ==**7 days of the receipt fo the application**==
		-  board shall ==**w/in 10 days of the receipt of a reference form AA**==  **recommend the name fo an Insolvency prof to AA against whom no disciplinary proceedings are pending** and the AA ==**shall appoint such prof for the purposes of the fresh start process**==
			- AA may give directions to erstwhile RP to share all info with new RP wrt the Fresh Start Process and to cooperate with teh new RP as may be required


<br>

#### Directions for compliances of restrictions s90
- RP may apply to AA for any of the following directions
	- compliance with restrictions under [[#^782e82|Section 85(3)]] in case of non compliance by debtor, or
	- compliance with [[#What are the General duties of debtor s88|General duties under Section 88]]
- RP can apply for **directions wrt any other matter under this chpter for which no specific provisions have been made**

<br>

#### Discharge Order - Section 92
<mark style="background: #00FFFE73;">Section 92</mark> 
##### time limit before which final list of qualifying debts is to be prepared and submitted to A?
- **At least 7 days before [[#Moratorium period]] comes to an end**
##### What will the AA do?
- Pass a ==**discharge order**== at the ==**end of the moratorium period**== for the ==**discharge fo the debtor from the qualifying debts mentioned**==
##### What are the liabilities that the debtor will be discharged from?
1. (a) penalties in respect of the [[#Qualifying debt - s79 19|qualifying debt]] from the date of application till the date of the discharge order;

2. (b) i**nterest including penal interest in respect of the qualifying debts from the date of application till the date of the discharge order**; and

1. (c) ==**any other sums owed under any contract in respect of the qualifying debts from the date of application till the date of the discharge order**==.


<br>


---
### Ch 3: Insolvency Resolution Process

```ad-note
- In case of individual insolvency, the debtors and creditors negotiate a  repayment plan, which is implemented under the supervision of a  resolution professional. 
- A ==bankruptcy process, entailing sale of the assets of the debtor, arise on failure of either the insolvency resolution process or implementation of repayment plan==

```

[[Insolvency Resolution Process 1.png]]

![[Insolvency Resolution Process 1.png]]

#### Application to initiate IRP by Debtor - s94 b

- A debtor who commits default either ==**personally**== or ==**through a resolution professional**== to the ==**adjudicating authority**==
- Where the ==debtor is a partner of a firm==, ***==such debtor shall not apply under this Chapter to the Adjudicating Authority in respect of the firm unless all or a majority of the partners of the firm file the application jointly.==***

##### When shall the debtor NOT BE ENTITLED 🔴 to make such application?
- if he is--
	1. (a) an [[#Undischarged bankrupt]];
	2. (b) undergoing a fresh start process;
	3. (c) undergoing an insolvency resolution process; or
	4. (d) undergoing a [[#Bankruptcy process]].
- debtor shall not be eligible to apply ==**if an application under this Chapter has been admitted in respect of the debtor during the period of twelve months preceding the date of submission of the application under this section.**==

<br>

#### Application by creditor to initiae IRP? - s95
##### Creditor
- May apply ==**by himself or jointly with other creditors**== or through a **[[#Resolution professional]]**
- A creditor may apply in relation to any partnership debt owed to him for initiating an insolvency resolution process against--
	1. (a) any one or more partners of the firm; or
	2. (b) the firm.
- Where an application has been made against one partner in a firm, any other application against another partner in the same firm shall be presented in or transferred to the Adjudicating Authority in which the first mentioned application is pending for adjudication and such Adjudicating Authority may give such directions for consolidating the proceedings under the applications as it thinks just
###### What details must the application contain?
- An application shall be accompanied with details and documents relating to--
	1. (a) the debts owed by the debtor to the creditor or creditors submitting the application for insolvency resolution process as on the date of application;
	2. (b) the failure by the debtor to pay the debt within a period of fourteen days of the service of the notice of demand; and
	3. (c) relevant evidence of such default or non-repayment of debt.

> - The creditor shall also provide a copy of the application to the debtor.

<br>

#### Interim Moratorium s96
- Begins ==**when application is filed**== under **section 94 or 95** in relation to all debts
##### When will it cease?
- On the date of ==**admission**== of such application
##### What happens during the interim moratorium?
- Any legal action or proceeding pending wrt **any debt** shall be **==deemed to have been stayed==** and
- the **creditors odf the debtor** ==**shall not initiate any legal action or proceedings in respect of any debt**==

###### What happens if the interim moratorium has been made in relation to a firm?
- then it ==shall opoerate== **==against all the partners fo the firm==** as on the date of application

<br>

#### Appointement of resolutional professional s97
1. If the RP has ==**been filed through RP**== -> then the AA **shall direct the board ==within 7 days==** of the date of application to **confirm that there are no disciplinary proceedings against the RP**
	- Board will **==within 7 days==** communicate to the AA **confirming or rejecting appointment** in writing and nominating another RP for IRP
2. Where application filed by ==**debtor/creditor himself**== and **not the resolution prof**, AA will **direct board ==w/in 7 days==** to ==**nominate a RP**== for IRP
	- such nomination will happen **within ==10 days==**

#### Can Resolution professional be replaced? s98 
- Yes; upon **application by the ==debtor== or ==creditor==**
##### Procedure?
- AA  will within **7 days** make ==reference to the **Baord**== for such replacement
- Board will **within 10 days** ==**recommend name of RP to the AA**== against whom no disciplinary proceedings are pending
##### Can creditors apply to AA for replacement of RP where it has been decided in the meeting of the creditors ?
- Yes 
##### Directions issuable to old RP?
1. to **share all info with the new RP** wrt IRP
2. to **cooperate with New RP** in such matters as may be required


<br>

#### Submission of Report by REsolution professional - s99
- He will **examine the application made by debtor or creditor** ==**within 10 days of his appointment**== and then submit **report to Aa for ==approving or rejecting the application==**
##### What evidence might RP require debtor to give where application is filed by creditor under section 95?
- he may require debtor to ==**prove repayment of the debt claimed as unpaid by the creditor**== by means of 
	1. evidence of electronic transfer
	2. evidence of encashment of cheque
	3. signed acknowledgement of creditor accepting receipt of dues

##### Can creditor dispute validity of debt where the debt for which application has been filed by creditor is registered with the information utility?
- NO
##### From whom all may the RP seek further info or application as may be required? - 99(4)
1. Debtor
2. Creditor
3. any other person who in his opinion may provide such info
###### Duration for furnishing such info
- within ==**7 days**== of **receipt of request**
##### What must the RP ascertain upon examination of application?
1. that the application ==**satisfies the requirement under 94 or 95**== -> see here ([[#Application to initiate IRP by Debtor - s94 b]] and [[#Application by creditor to initiae IRP - s95]])
2. That the the ==applicant has provided info and explanation== sought by the RP under **[[#From whom all may the RP seek further info or application as may be required - 99 4|s99(4)]]**

>- Upon such examination, he may ==**recommend Acceptance or rejection of application**==
>	- he shal **record reasons for recommending the acceptance or rejection of the application** in the report under **ss7** <mark style="background: #00FFFE73;">ss9</mark> 


<br>

##### What if RP finds that the debtor is eligible for a FRESH START PROCESS under CH 2?
- then he may **submit a report** recommending that the **application by the debtor under section 84** be treated as one under [[#Interim moratorium period s81|Section 81]]

<br>


<br>

#### Adjudicating authority to reject or admit w/in 14 days
- Upon admission -> it may issue instructions for ==**purpose of conducting negotiations b/w debtors and creditors**== for arriving at a **[[#Repayment Plan]]**
##### What if AA rejects application under s 94,95 on basis of report submitted by RP that the application was made tith intention to defraud his creditors or the RP?
- The AA will record that the <mark style="background: #FF4E00A6;">**Creditor** is **entitled to file for a bankruptcy order** under CH4</mark>  #important 

<br>

#### Moratorium - s101
- When **application is admitted** under s 100, then moratorium begins
##### Constraints imposed?
1. Any pending legal action or proceeding shall be stayed and 
2. the creditors shall not initiate any legal action w.r.t. to any debt and 
3. the debtor shall not transfer, alienate, encumber or dispose of any of his assets or his legal rights or beneficial interest.
##### What if Moratorium imposed in relation to firm?
- It shall operate against ==**all members fo the firm**==
##### When will moratorium end? 🔴
1. at the end of period of ==**180 days**== beginning with the **date of admission of application** or 
2. the **date on which AA passes an order on repayment plan under s114**
##### Exception?
- M will **not operate against such transaction s maybe notified** by Central govt in **consultation w/financial sector**

<br>

#### Claims of Creditors - 102
##### Public notice to be issued
- Issued by AA **within 7 days of passing admission order under s 100**
	- inviting ==claims from all creditors== within **==21 days== of issuing such notice**
##### Contents of notice
- (a) details of the order admitting the application;
- (b) particulars of the resolution professional with whom the claims are to be registered; and
- (c) the last date for submission of claims.
##### Mode of publication
- (a) published in at least one English and one vernacular newspaper which is in circulation in the state where the debtor resides;
- (b) affixed in the premises of the Adjudicating Authority; and
- (c) placed on the website of the Adjudicating Authority.

#### Registration fo claims of creditors -103
- to be done with ==**resolution professionals**== by **sending details fo the clims** by means of 
	1. **electronic communication**
	2. **courier**
	3. **speed post**
	4. **registered letter**

#### List of creditors
##### How will it be made
- On the basis of 
	1. **information** disclosed in the **==application filed by debtor under 94 or 95==**
	2. claims received under [[#Claims of Creditors - 102|Section 102]]
##### Duration for preparation of list
- within ==**30 days from date of issuance of notice**==

<br>

#### Repayment Plan
##### Who will prepare?
- **debtor** in **consultation with** the **resolution professional** -> it will contain ==proposal to creditors for **restructuring of his debts or affairs**==
##### What may the plan authorise or require the RP to do?
1. to run the debtor's business on his behalf or 
2. realise his assets or 
3. administer or dispose of any of his funds.
##### Contents of plan may include?
- (a) justification for preparation of such repayment plan and reasons on the basis of which the creditors may agree upon the plan;
- (b) provision for payment of fee to the resolution professional;
- (c) such other matters as may be specified.
#### Report of RP on the plan - s106
- Shall be submitted to AA within 21 days of the last submission of claims
##### What shall it include?
- (a) the repayment plan is i**==n compliance with the provisions of any law for the time being in force;==**
- (b) the repayment plan has a ==**reasonable prospect of being approved and implemented;**== and
- (c) there is a ==**necessity of summoning a meeting of the creditors, if required, to consider the repayment plan:**== ; if no such need, *reasons for the same to be stated*
	- meeting of creditor s to b held **not less than 14 days after** but **not more than 28 days after** the **==submission of report on the plan==**

##### Is the meeting mandatory? 
- No provided that reasons for doing away with it are stated

<br>

#### Meeting of Creditors s107
##### When notice to be issued?
- At least ==**14 dys before meeting**==
##### Notice to whom?
- Creditors in the list under s104
##### Contents of Notice
- Address of AA to which the plan and report has been submitted
- (a) a copy of the repayment plan;
- (b) a copy of the statement of affairs of the debtor (**statement of affairs to provide info on the creditors of the debtor, the debts, assets, and liabilites and other necessary info**);
- (c) a copy of the said report of the resolution professional; and
- (d) forms for proxy voting.

<br>


##### Conduct of meeting s108
- In accordance with s109,110,111
- Creditors ==may **approve, modify or reject the plan**==
	- If modification suggested, ==RP should ensure that permission of debtor is obtained for each of them==
- Creditors shall be entitled to vote at every meeting in respect of the [[#Repayment Plan]] in **accordance with ==voting share assigned==** - s109
###### Who to decide respective voting shares of creditors?
- Resolution proessional
###### Adjounment of meeting?
- Upon showing sufficient cause, **may be adjourned for ==period of not more than 7 days at a time==**
###### What is unliquidated amount? Can a creditor be entitled to vote in respect of such debt?
- Unliquidated amount refers to **amount that is not known**
- the creditor shall **not be entitled to vote in respect of such debt**

##### When shall the creditor be barred from voting? - 109(4)
- If his name is **not mentioned in list of creditors under s104**k, or
- if he is an **[[#Associate of debtor]]**

<br>


<br>

#### Rights of secured creditors wrt repayment plan
1. They are entitled to participate and vote in meetings
2. if **secured cred** participates in the meetings of the creditors and votes in relation to the repayment plan, then he shall ==**forfeit his right to enforce the security during the period of the repayment plan in acc w/ terms of the plan**==
3.  Where a secured creditor does not forfeit his right to enforce security, he shall submit an affidavit to the resolution professional at the meeting of the creditors stating -
	- (a) that the right to vote exercised by the secured creditor is only in respect of the unsecured part of the debt; and
	- (b) the estimated value of the unsecured part of the debt.
 1. In case a secured creditor participates in the voting on the repayment plan by submitting an affidavit under sub-section (3), the secured and unsecured parts of the debt shall be treated as separate debts.


<br>

#### Approval of Repayment plan by creditors s111
##### Requriement?
- Majority ==greater than **three-fourth in value of creditors present in person/by proxy**==

<br>

#### Report of the meeting of creditors on repayment plan - s112
- RP will prepare a report of the meeting of the creditors on the repayment plan
##### Details of the report under s112?
- (a) **==whether the repayment plan was approved or rejected and if approved, the list the modifications, if any;==**
- (b ) the resolutions which were proposed at the meeting and the decision on such resolutions;
- (c ) list of the creditors who were present or represented at the meeting, and the voting records of each creditor for all meetings of the creditors; and
- (d) such other information as the resolution professional thinks appropriate to make known to the Adjudicating Authority.
##### To whom will copy of the report of meeting of creditors be provided? s113
1. the debtor
2. creditors including those not present in meeting
3. **==Adjudicationg authority==**

<br>


<br>

#### Order of AA on the repayment plan? s114
1. AA will ==either **approve or reject the plan**== on the **basis of the report of the meeting of the creditors** submitted by the **resolution professional** under s112
	- if meeting is not summoned [[#Is the meeting mandatory|see here]], then the decision shall be on the basis of report under [[#Report of RP on the plan - s106]]

##### Effect of Order of AA s115
###### Where approved 🟢
- such ==**payment**==  
	1. shall **take effect** **<u>as if proposed by the debtor in the meeting</u>**
	2. shall be ==**binding on the creditors mentioned in the plan and th edebtor**==
###### Where rejected 🔴
- debtors and creditors ==**shall be entitled to file for bankruptcy under the next chapter**==

<br>

#### Implementation and Supervision of the plan?
- to be appointed by RP appointed under [[#Appointement of resolutional professional s97]] or [[#Can Resolution professional be replaced s98]]

<br>

#### Completiton of Repayment plan -> whatto be done?
- Resolution professional shall **==within 14 days of completition of the plan==** forward to a) **persons bound by the plan** and the **AA** the following documents
	1. **a notice that the repayment plan has been fully implemented;** 
	2. **copy of a report by the resolution professional summarising all receipts and payments made in pursuance of the repayment plan and extent of the implementation of such plan as compared with the repayment plan approved by the meeting of the creditors**
##### Can the time of 14 days be extended?
- YEs by **7 days max**

<br>

#### When does the plan come to end prematurely? 118
- If it **==has not been implemented fully in respect of all person bound by it==** within the **<mark style="background: #00FF3E8C;">period as mentioned in</mark> ** the [[#Repayment Plan]]**
##### Contents of report to be submitted to AA upon premature end of plan?
- ==**(a) t h e receipts and payments made in pursuance of the repayment plan;**==
- (b) t h e **reasons for premature end** of the repayment plan; and
- (c) the ==details of the creditors whose claims have not been fully satisfied.==
###### What about the creditors whose claims have not fully been satisfied?
- They can file for ==**bankruptcy**==

<br>


<br>

#### Discharge Order 119
- To be passed by by **AA** upon **application by resolution profession** for ==**discharge order**== in relation **debts mentioned in the plan**
- repayment plan may provide for -
	- (a) **==early discharge==**; or
	- (b) ==**discharge on complete implementation of the repayment plan.**==




----
### Ch 4: Bankruptcy Order for Individuals and Partnerhsip firms (121-148)
[[Bankruptcy Order for Individuals an Partnership Firms.png]]
![[Bankruptcy Order for Individuals an Partnership Firms.png]]


#### Who can make application for bankruptcy of debtor? s121
1. **Debtor**
	- where D is a firm, the application **may be filed by any of its partners**
2. **Creditor individually or jointly with other creditors**

##### When can such application be made?
1. Where order was passed under **s100(4) i.e., where the application for IRP is rejected**
2. where an order is passed under **ss2 of s115** meaning where the ==**repayment plan is rejected**==
3. under s118(3) where **repayment plan ends prematurely and is not completely implemented**
##### Time period w/in which such application must be made?
- Within 3 months of the date fo the order passed by the A under the aforementioned sections


<br>

#### Application by Debtor
- Application to be accompanies by 
	1. records of **insolvency process under Ch III of PartIII**
	2. statement of affairs of debtor
	3. **copy of AA order under CHapter III**  that **==permits D to apply for bankruptcy==**
##### Can D propose Insolvency professional as the Bankruptcy trustee?
- Yes, he may prpose Insolvency professional as the [[#“bankruptcy trustee”]]
##### Can this application be withdrawn?
- Yes but ==**only with the leave of AA**==

#### Application by creditor s123
##### Contents of Application
1. records of **insolvency process under Ch III of Part III**
2. **copy of AA order under Chapter III**  that **==permits C to apply for bankruptcy==**
3.  **details of the debts owed by the debtor to the creditor as on the date of the application for bankruptcy**
4. such other information as may be prescribed.
##### Contents of application filed in respect of debt which is secured?
 1. a **statement by the creditor having the right to enforce the security that he shall**, in the event of a **bankruptcy** **order** being made, ==give up his security for the benefit of all the creditors of the bankrupt==, or
 2. a statement by the creditor stating
	 1.  that **the application for bankruptcy is only in respect of the unsecured part of the debt;**
	 2.  an estimated value of the unsecured part of the debt.
>if application is made under this clause, then the **secured** and **unsecured parts** of the debt ==**shall be treated as separate debts**==

##### Can the creditor propose an insolvency professional as the bankruptcy trustee in the application for bankruptcy?
- Yes ss4

##### What happens if the debtor is deceased?
- Bankruptcy application to be **==filed aginst his legal representatives==**


<br>

#### Effect of Application - Interim Moratorium
##### When will it commence? 
- On the day of making the application; it will apply to **all actions against the properties of the debtor is respect of his debts**
##### When will it cease to have effect?
- On the **[[#Bankruptcy commencement date]]**

##### What happens during the interim moratorium period?
- ==**any pending legal action or legal proceeding against any property of the debto**==r in respect of any of his **debts** shall be **==deemed to have been stayed==**;
- the **==creditors of the debtor shall not be entitled to initiate any legal action or legal proceedings against any property of the debtor==** in respect of any of his debts.


<br>


<br>

#### Appointment of Bankruptcy trustee - s125
1. If IP is proposed as the [[#“bankruptcy trustee”]]
	1. AA shall **direct the board** **==within 7 days of receipt fo the application for bankruptcy==** to **==confirm==** that there are ==**no disciplinary proceedings against the professional**==
	2. In ==**10 days**==, the **board shall** either
		- confirm the IP as BT or
		- reject the proposed appointment
2. If not proposed?
	- AA will **direct board w/in 7 days of receipt of application** to ==**nominate a Bankruptcy trustee**==
	- Board in **==10 days==** of receiving direction **shall ==nominate a Bankruptcy trustee==**

<br>


<br>


#### Bankruptcy order (confirms the appointment of BT among other things) - section 126
#important 
1. To be passed **==within 14 days of recipt fo the confirmation or nominaton of the Bankruptcy trustee==** under section 125
2. The **copy of application for bankruptcy** and the **copy of bankruptcy order** will be submitted the **==creditors, bankrupt, and bankruptcy trustee==**

##### Until when will the Order have effect? - s127
- Until ==**discharge of debter**== under <mark style="background: #00FFFE73;">section 138</mark> 
##### Effect of Order
1. estate of [[#Bankrupt]] will **vest in the [[#“bankruptcy trustee”]]**
2. the **==estate of the bankrupty==** shall be **==divided among his creditors==**
3. Subsection 2 provides that the order will not affect the **right of any secured creditor to realise or otherwise deal with his security interest in the same manner as he would have been entitled if the order had not been passed**; 
	- subject to this, in a **creditor of the bankrupt** indebted in ==respect of any debt **claimed as bankruptcy debt**== **shall not**
		1. **initiate any action against the property of the bankrupt wrt the debt, or**
		2. commence any suit/other legal proceedings **<u>except with leave of AA</u>** on the terms imposed by AA
###### Within how many  days must the secured creditor entitled to any interest in respect of his debt take action to realise his security?
- ==**within thirty days**== from the **[[#Bankruptcy commencement date]]**; *otherwise he will not be entitled to any interest in respect thereof*

<br>


##### Within how many days of passage of the Order should the bankrupt submit his statement of financial position? - s129
- within ==**7days**== of [[#Bankruptcy commencement date]]
###### What if the bankrupt is a firm?
- Then its partners **on the date of the order** shall **submit ==joint financial position of the firm==**
- Each partner will also **submit statement of his financial position**


<br>


<br>

#### Public Notice inviting claims form creditors - s130
##### To whom should the notice be given
- Within ==**10 days**== of the [[#Bankruptcy commencement date]] to the 
	1. **creditors mentioned in the ==statement of affairs== submitted by the [[#Bankrupt]] under s129** ..OR
	2. **the application for [[#Bankruptcy]]** ==submitted by the bankrupt==

##### Contents of public notice inviting claims form creditors?
1. Last date up to which claims shall be submitted
##### Mode of publication
1. Leading newspapers, one English and another in vernacular having **sufficient circulation where the bankrupt resides
2. affixed on the ==**premises of the Adjudicating Authorit**==y
3. **==website of the Adjudicating Authority==**

<br>


<br>

#### Registration of claims 131
##### Duration?
- Within ==**7 days of public of the Public notice**==
	- <mark style="background: #00FF3E8C;">**details of claims**</mark> to be **sent to the [[#“bankruptcy trustee”]]**

#### Preparation of the List of creditors 132
##### Duration?
- To be prepared **by the [[#“bankruptcy trustee”]]** **==within 14 days from==** the **[[#Bankruptcy commencement date]]** 
##### List to be prepared on the basis of?
1. information **disclosed by the [[#Bankrupt]]** in the **==application for bankruptcy==** filed under **Section 118** and the **statement of affairs** prepared under [[#Appointment of Bankruptcy trustee - s125|Section 125]] and 
2. claims received by the [[#“bankruptcy trustee”]] under **[[#Public Notice inviting claims form creditors - s130|Section 130]]**
#### Summoning Meeting of Creditors 133
##### Duration?
- Within **==21 days==** of **[[#Bankruptcy commencement date]]**; to be called by **[[#“bankruptcy trustee”]]**
##### Notice to whom?
- Every creditor present in the  list prepared under [[#Preparation of the List of creditors 132|Section 132]] 
##### Contents of notice
1. Date of the meeting (**should not be later than 21 days from [[#Bankruptcy commencement date]]**)
2. shall be accompanies with **forms of proxy voting**


<br>

<br>


#### Conduct of meeting 134
##### Who convenes the meeting?
- **[[#“bankruptcy trustee”]]**; he will **decide the quorum**; meeting to be conducted **only if quorum is present**

##### Business with regard to which resolution may be passed
1. Establishement of **==committee of creditors==**
2. any other business as [[#“bankruptcy trustee”]] deems fit to be transacted
##### Recording of minutes, signing, retaining?
- To be done by the **[[#“bankruptcy trustee”]]**
##### Adjourment?
- FOr **not more than 7 days at a time**

<br>

#### Voting rights of creditors 135
##### Who to have right to vote?
- Creditors **mentioned in the list** under **[[#Preparation of the List of creditors 132|Section 132]]** or his proxy in acc with teh ==**voting share assigned to him**==
###### Who to decide voting share?
- **[[#Resolution professional]]**
##### Can creditors vote in respect of a debt for an unliquidated amount? 🔴
- No
##### Who shall NOT be entitled to vote? 🔴🔴
1. creditors **not mentioned in the list** under [[#Preparation of the List of creditors 132|section 132]]
2. **creditors** who are <mark style="background: #FF4E00A6;">associates of the bankrupt</mark> 

<br>


<br>

#### Administration and Distribution of Estate of Bankrupt
- To be ==**conducted by**== the **[[#“bankruptcy trustee”]]** #important 
	- in acc with [[#Ch 5 Administration and Distribution of the Estate of the Bankrupt 149-178]]

<br>

#### Completion of Administration s137
1. Meeting of **committee of creditors** to be convened on <mark style="background: #00FF3E8C;">completion of administrationa nd distrubition of the bankrupt in acc with chapter 5</mark> 
2. [[#“bankruptcy trustee”]] shall **provide the Committe of creds** with a **==report of the administration fo the estate of the bankrupt==** 
3. THe committe **shall approve the report** by by the BT ==**within 7 days of the receipt fo the report**== and **==determine if the trustee should be released under==**  **<mark style="background: #00FFFE73;">section 148</mark> **
4. BT to **retain sufficeitn sum** from  the estate fo the bankrupt to meet expenses fo convening and conducting the meeting under s137

<br>


<br>

#### DISCHARGE ORDER s138
- Adjudicating authority shall ==**pass discharge order on such application**==
- copy to be provided to the board for recording entry
##### Who to apply?
- **[[#“bankruptcy trustee”]]**
##### Duration?
- within **==7 days of the approval of CoC of the completition of administration fo the estates==** under <mark style="background: #00FFFE73;">section 137</mark> 

#### Effect of Discharge s139
- **<mark style="background: #00FF3E8C;">Release bankrupt from all bankrupty debt</mark>** 
- The discharge will not 
	1. affect functions of [[#“bankruptcy trustee”]]
	2. affect operations of [[#Ch 4 Bankruptcy Order for Individuals and Partnerhsip firms 121-148]], [[#Ch 5 Administration and Distribution of the Estate of the Bankrupt 149-178]] or Part II
	3. **release [[#Bankrupt]] from any debt incurred by means of fraud/breach of trust to which he was party**
	4. **discharge bankrupt** form **[[#Excluded debt]]**

<br>

<br>


#### Disqualification of Bankrupt? s140
#important 
- From **[[#Bankruptcy commencement date]]**, the **BANKRUPT** shall  be disqualified from
	1. from being **appointed or acting as a trustee or representative in repsect of any trust or settlement**
	2. from **being appinted or acting as public servant**
	3. from bain **elected ot any public officer** where the **appointment of such office is by election**, and 
	4. being **elected or sitting or voting as member of any locla authority**
##### When will such disqualificatio cease?
1. if the he is ==**discharged**== under **[[#DISCHARGE ORDER s138]]**
2. where the **bankruptcy order against him** has been ==**modified or recalled**== under <mark style="background: #00FFFE73;">Section 142</mark> ->[[#Modification or recall of Bankruptcy order - Section 142|see here]]

<br>


<br>

#### Restrictions on Bankrupt - s141
- From [[#Bankruptcy commencement date]], HE SHALL
	1. **NOT ACT** as the ==**director of any company**==; shall also not **directly or indirectly ==take part in or be conerned in the promotion, formation, or management of a company==**
	2. **be prohibited** from **creating charge on his estate** or **taking further debt** -> ***==without the sanction of==*** the **[[#“bankruptcy trustee”]]**
	3. **be required** 🟢 to **inform his business partners** that he **<u>is undergoing a [[#Bankruptcy process]]</u>**
	4. **before ==entering into any financial or commercial transaction==** of **prescribed value** whether **individually or  jointly**, he **==shall inform all parties involved in the transaction that he is underdoing a [[#Bankruptcy process]]==** 
	5. shall be **incompetent** to ==**maintain any legal action or proceedings inrelation to bankruptcy debts**== *without prior sanction from AA*
	6. <mark style="background: #FF5582A6;">shall **not be allowed to travel overseas**</mark>  without the *permission of AA*
##### When shall these restrictions cease?
- if 
	1. the **bankruptcy order against him** is ==**modified or recalled**== under <mark style="background: #00FFFE73;">section 142</mark>  -> [[#Modification or recall of Bankruptcy order - Section 142|see here]]
	2. he is <mark style="background: #00FF3E8C;">discharged</mark>  under [[#DISCHARGE ORDER s138|Section 138]]

<br>


<br>

#### Modification or recall of Bankruptcy order - Section 142
##### When can the order be recalled?
- On ==**application**== or **==suo motu==** **<u>whether or not the [[#Bankrupt]] is discharged</u>** if it **appears to the AA** that
	1. there exists ==**apparent error on the fact of such order**==
	2. both the **bankruptcy debts and exxpenses** have **after the making of the order** ==either **been paid for** or **secured** to the satisfaction of the AA==

- Where the Adjudicating Authority modifies or recalls the bankruptcy order under this section, any sale or other disposition of property, payment made or other things duly done by the bankruptcy trustee shall be valid except that the property of the bankrupt shall vest in such person as the Adjudicating Authority may appoint or, in default of any such appointment, revert to the bankrupt on such terms as the Adjudicating Authority may direct. 

>A copy of the order passed by the Adjudicating Authority shall be provided to the Board, for the purpose of recording an entry in the register referred to in section 191. **The modification or recall of the order by the Adjudicating Authority shall be binding on all creditors so far as it relates to any debts due to them which form a part of the bankruptcy.**

<br>

#### Fees of bankruptcy trustee? s144
- bankruptcy trustee appointed for conducting the bankruptcy process **==shall charge such fees in proportion to the value of the estate of the bankrupt.==** 
The fees for the conduct of the bankruptcy process shall be paid to the bankruptcy trustee from the distribution of the estate of the bankrupt in the manner provided in <mark style="background: #00FFFE73;">section 178.
</mark> 

<br>

#### Can the Bankruptcy trustee be replaced? - s145
- Yes
##### Procedure
- He can be replaced where the **==committe of creds==** is of the opnion **anytimge during the [[#Bankruptcy process]]**, a [[#“bankruptcy trustee”]] is required to be replaced; 
	- they ay replace him with **another trustee**
- Application to be given to ==**AA**==
##### Procedure - Adjudicating authority?
- ==**within 7 days**== of receipt of application, the AA shall **direct the board to recommend for replacement of BT**
- Board shall ==**within 10 days of the direction of AA**== -> **==recommend==** a **bankruptcy trustee** against whom no disciplinary proceedings are pending
- Within ==**14 days from reccommendation**== -> **AA shall appoint new BT**

<br>

#### Can Bankruptcy trustee resign? - 146
- Yes  if ther is 
	1. ==**conflict or interest**==, or 
	2. ==change in circumstance== that **preclude the discgarege of his duties** as **[[#“bankruptcy trustee”]]**
##### Procedure thereafter?
- AA shall ==**within 7 days of acceptance fo resignation**== -> **direct the ==board==** to **recommend replacement**
- Board will recommend within **==10 days of direction==**
- AA will appoint such nominee as trustee ==**within 14 days of receiving recommendation**==

<br>

#### Vacancy in office of BT
>This section provides that if a vacancy occurs in the office of the bankruptcy trustee for any reason other than his replacement or resignation

- Where ther is vacancy
	1. Adjudicating Authority shall direct the Board for replacement of a bankruptcy trustee. 
	2. The Board shall, within ten days of the direction of the Adjudicating Authority, recommend a bankruptcy trustee as a replacement. 
	3. The Adjudicating Authority shall appoint the bankruptcy trustee recommended by the Board within fourteen days of receiving the recommendation. 
	4. ==The earlier bankruptcy trustee shall deliver possession of the estate of the bankrupt to the bankruptcy trustee, on the date of his appointment.==
- bankruptcy trustee ==**shall give a notice of his appointment to the committee of creditors and the bankrupt within seven days of his appointment.**== 
- The earlier bankruptcy trustee replaced under this section shall be released in accordance with the provisions of <mark style="background: #00FFFE73;">section 148.
</mark> 


<br>

#### Release of Bankruptcy trustee - s148
- This section provides that a bankruptcy trustee shall be released from his office with effect from 
	1. the date on which the Adjudicating Authority passes an order appointing a new bankruptcy trustee in the event of 
	2. replacement,
	3. resignation or 
	4. occurrence of vacancy under sections 145, 146 or Section 147

<br>



---
### Ch 5:  Administration and Distribution of the Estate of the Bankrupt (149-178)

#### What are functions of Bankrptcy Trustee? 149
1. (a) **investigate the affairs of the bankrupt;**
2. (b) **realise the estat**e of the bankrupt; and
3. (c) ==**distribute the estate**== of the bankrupt.

<br>

#### Duties  of Bankrupt towards BT? 150
- Bankrupt shall assist in 
	1. (a) giving to the bankruptcy trustee the information of his affairs;
	2. (b) attending on the bankruptcy trustee at such times as may be required;
	3. (c) giving notice to the bankruptcy trustee of any of the following events whichhave occurred after the bankruptcy commencement date, -
	    - (i) acquisition of any property by the bankrupt;
	    - (ii) devolution of any property upon the bankrupt;
	    - (iii) increase in the income of the bankrupt;
	1. (d) doing all other things as may be prescribed.

<br>

#### Rights of Bt
- can do following for performing his functions under this chapter by **his official name**:
	1. (a) **hold property of every description;**
	2. (b) make **contracts**;
	3. (c) **sue and be sued;**
	4. (d) **enter into engagements in respect of the estate of the bankrupt;**
	5. (e) employ persons to assist him;
	6. (f) execute any power of attorney, deed or other instrument; and
	7. (g) <u>do any other act which is necessary or expedient for the purposes of or in connection with the exercise of his rights.</u>

<br>


<br>

#### General Powers of Bankruptcy Trustee
#important 
- In discharge of his duties he may
	1. sell any part of the **estate of the bankrupt**
	2. give **receipts** for any oney received by him
	3. prove, rank, claim and draw a dividend in respect of such debts due to the bankrupt as are comprised in his estate;
	4. where any property comprised in the estate of the bankrupt is held by any person by way of pledge or hypothecation, exercise the right of redemption in respect of any such property subject to the relevant contract by giving notice to the said person;
	5. **where any part of the estate of the bankrupt consists of securities in a company or any other property which is transferable in the books of a person**, exercise the right to transfer the property to the same extent as the bankrupt might have exercised it if he had not become bankrupt; and
	 1. **deal with any property comprised in the estate of the bankrupt to which the bankrupt is beneficially entitled in the same manner as he might have dealt with it.**

<br>

#### For what acts of the Bankruptcy trustee is the approval of creditors required?
> ![[Part III IBC-1.png]]


<br>

#### When shall the estate of bankrupt vest in bankruptcy trsutee
- On the ==**date of his appointment**==
- Vesting to take place **without any conveyance assignemnt or transfer**

<br>


<br>

#### What all may constitute estate of Bankrupt? s155
#important #important 
- a==ll property belonging to or vested in the bankrupt at the bankruptcy commencement date;==
- the ==**capacity to exercise and to initiate proceedings for exercising all such powers in or over or in respect of property as might have been exercised by the bankrupt for his own benefit**== at the bankruptcy commencement date or before the date of the dischargeorder passed under section 138; and
- (c) ==all property which by virtue of any of the provisions of this Chapter is comprised in the estate==.
#### What cannot be included in the estate of the bankrupt?
1. [[#Excluded assets - s79 14]]
2. property **held by bankrupt on ==trust for any other person==**
3. all **==sums due to any workman or employee from the provident, pension or gratuity funds==**, adn
4. such **assets as may be notified by the Central govt** in consultation with any financial sector regulator

<br>


#### **The Bankrupt/his banker/his agent must shall deliver the property and docs to the Bankruptcy trustee** - Section 156

<br>

#### What shall the Bankruptcy trustee take possession and control of? s 157
- all property, books, papers, and other recoreds relating to the estate of the banktupt or affairs fo the bankrupt **which belong to him or are in his control or possession**
- Where any part of the estate of the bankrupt consists of things in actionable claims,they shall be deemed to have been assigned to the bankruptcy trustee without any notice of the assignment.

<br>


#### Is the debtor restrained from disposing off his proerty during the period between filing of application and the bankruptcy commencement date? s158
- YES
##### Effect of such disposition?
- Void
- Any disposition of property shall not give rise to any right against any person, in respect of such property, ==***even if he has received such property before the bankruptcy commencement date in good faith, for value and without notice of the filing of the application for bankruptcy.***==
	- Property does not include that which is **held by debtor in trust for any other person**

<br>

#### What happens to after-acquired propoerty of bankrupt? - s159
- bankruptcy trustee ==**shall be entitled to claim for the estate of the bankrupt, any after-acquired property by giving a notice to the bankrupt**==. 
	- A notice shall not be served in respect of excluded assets or any property which is acquired by or devolves upon the bankrupt after a discharge order is passed under section 138.
##### What is after acquired property?
_Explanation._—For the purposes of this section, the term “after-acquired property” means **==any property which has been acquired by or has devolved upon the bankrupt after the bankruptcy commencement date.==**

##### What if any person acquires any right over AFTER ACQUIRED PROPERTY in GOOD FAITH, for VALUE, and WITHOUT NOTICE OF BANKRUPTCY?
- sUCH CASES -> the [[#“bankruptcy trustee”]] shall <mark style="background: #FF5582A6;">**not be entitled to claim from such person under this section**</mark> 

<br>

#### Onerous Property of Bankrupt? s160
##### What is Onerous proerty?
1. any **unprofitable contract** and
2. any other **property** that **forms part of estate** of the bankrupt which is ==**unsaleable**== or ==**not readily saleable**==
##### Procedure - Disclaim as in renounce legal title to
- Bankruptcy trustee may, by **giving notice to the bankrupt or any person interested in the onerous property**, ==disclaim any onerous property which forms a part of the estate of the bankrupt.== 
- The bankruptcy trustee may give the notice notwithstanding that he has taken possession of the onerous property, endeavoured to sell it or has exercised rights of ownership in relation to it. A notice of disclaimer shall determine, as from the date of such notice, the rights, interests and liabilities of the bankrupt in respect of the onerous property disclaimed, discharge the bankruptcy trustee from all personal liability in respect of the onerous property as from the date of appointment of the bankruptcy trustee.
##### Where Notice to disclaim onerous property not necessary? -161
- No notice of disclaimer under section 160 shall be necessary i==**f a person interested in the onerous property has applied in writing to the bankruptcy trustee or his predecessor requiring him to decide whether the onerous property should be disclaimed or not**==; and ==**a decision has not been taken by the bankruptcy trustee within seven days of receipt of the notice.**== 
- Any <mark style="background: #00FF3E8C;">onerous property which cannot be disclaimed shall be deemed to be part of the estate of the bankrupt</mark> .

##### What about disclaimer of leasholds? When can that be done? -162
- BT is **not entitled to discliam any lease hold** ***unless*** 
	1. a ==notice of **disclaimer** has been **served on every interested person**== adn 
	2. **no application objecting to the disclaimer has been made by the  interested person**
###### Where application objecting to dislaimer has been filed by the interested person?
- The AA shall, AA has directed under s163 that the disclaimer shall take effect #doubt 

<br>

#### Challenge against Disclaimed Property - s163
##### Who can Challenge?
1. any person who ==**claim interest in it**==
2. any person who is ==**under any liability in respect of the property**==, or
3. wher the **disclaimed prop** is a ==**dwelling house**==, <u>any person who **on the date of application for bankrupcy** ==**was in occupation of or entitled to occupty th ehous**==e</u>
##### When shall the AA order in favour of person who is under any liabiolity in respect of the disclaimed property?
- Only when it is satisfied that ==**it would be justt to do so for the purpose fo compensating the person**==

<br>


<br>


<br>

#### Undervalued transactions - 164
##### When can the Bankruptcy trustee apply to the AA for an order in respec to fundervalued transactions?
- When such transactions have taken place ==**between a bankrupt and any person**==
##### ⭐ When can such transaction have been entered into by a bankrupt?
- #important where he makes
	1. **==gift==** to that person
	2. **==no consideration has been received by that person==** from bankrupt
	3. it is in consideration of marriage, or
	4. it is for a consideration the value of which in money's worth is ==**significantly less than the value in money or money's worht of the consideration provided by the bankrup**==

##### When should the transaction have been entered into?
1. It shouldhave been entered into ==**during the period of 2 years ending on the filing of the application for bankruptcy**== and **<mark style="background: #FF4E00A6;">caused the bankruptcy process to be triggered</mark>** 

##### Transaction between bankrupt and his associate?
transaction between ==**bankrupt**== andhis **[[#Associate of debtor|associate]]** ***during preceding 2 years prior to making application for bankruptcy*** shall be ==**deemed to be an undevalued transaction under this section**== 

##### Procedure AA
1. may pass an order ==**declaring an undervalued transaction void**== #important 
2. pass an order ==**requiring any property transferred as part fo such transaction**== to be <mark style="background: #FF4E00A6;">**vested with**</mark>  the **[[#“bankruptcy trustee”]]** as part of ==**estate of the bankrupt**== and
3. pass any order for ==**restoring the position to what it wuld have been if the bankrupt had not entered into the undervalued transaction**==

###### 🔴 When shall such order NOT be passed?
- When it is shown that the transaction was undertaken in the ==**ordinary course of business of the bankrupt**==
- However, this does not apply if the **transadction was undertaken ==between==** the **bankrupt and his [[#Associate of debtor|associate]]** 


<br>

#### Preference Transactions - 165
##### When can apply?
- when **bankrupt** has **==given preference to any person==**
##### Criteria for deeming transaction as giving preference to an associate of the bankrupt? 165(2)
- trans should have been **entered into by the bankrupt with the [[#Associate of debtor|associate]]** **==during the period fo 2 years ending on the date fo application for bankrupty==**
- this transaction ==**should have caused the bankruptcy to be triggered**== #important 
###### Other transactions? 165(3)
- trans should have been entered into by the bankrupt during the ==period of **6 months ending on the date of application for bankruptcy**==
 - this transaction ==**should have caused the bankruptcy to be triggered**== #important 
##### When shall the transaction be deemed to have been made giving preference to person
1. the ==**person is the creditor orsurety or guarantor**== for nay debt of the bankrupt, and
2. the bankrupt ==**does anyting or suffers antying to be done**== which has the **effect of ==putting that person into a position which in the even of the debtor becoming bankrupt==**, <mark style="background: #00FF3E8C;">such person will be in a better position than the bankrupt would have been, had that thing not been done</mark>  #important #important #important 
##### PROCEEDINGS BY AA
###### When Order voiding transaction to be passed
- AA may
	1. AA **may** ==**pass an order declaring the transaction giving preference to be void**==
	2. may pass an order **==requiring any property transferred in respect of a transaction giving preference==** to be **==vested with the==** [[#“bankruptcy trustee”]] as a ==**part of the estate of the bankrupt**==
	3. pass any other order as it thinks  fit for restoring the position to what it would have been if the bankrupt had not entered into the transaction #important 
###### When such order SHALL NOT BE PASSED?
such order voiding transaction shall not be passed **unless the bankrupt was influenced in his decisionof giving preference t a person by reason to produce in relation to that person an effect under **<mark style="background: #00FFFE73;">subsection 8 of this section</mark>  -> [[#When shall the transaction be deemed to have been made giving preference to person|see here(point 2)]]

##### Presumption of PREFERENCE when the person is an associate of the bankrupt for other reasons that only being his employee
- if such is the case ==**at the time of transaction**== -> it shall be <mark style="background: #00FF3E8C;">**presumed that the bankrupt was influenced in his decision**</mark> 


<br>

#### Effect of Order for Undervalued or Preference transactions - s166
- Combined reading of 166(1) and (2):
	- if the interest was acquired in **==good faith==** and for ==**value**== and ==**without notice that the bankrupt entered into the transaction at an undervalue or for giving preference**== and ==**without notice that the bankkrupt has filed an application for bankruptcy or a bankruptcy order has been passed**== and ==**by any person who at the time of acquiring interest**== was ***not an [[#Associate of debtor|associate of the bankrupt]]***, <mark style="background: #FF4E00A6;">THe order of the AA shall not</mark> 
	    1. give rise to a ==**right against a person interested in the property**== which was a**cquired in an undervalued transaction or a transaction giving preferenc**e, **whether or not he is the person with whom the bankrupt entered into such transaction** and 
	    2. re==**quire any person to pay a sum to the bankruptcy trustee in respect of the benefit received from the undervalued transaction or a transaction giving preference**==, whether or not he is the person with whom the bankrupt entered into such transaction.

>NOTE: THE CONDITIONS OF **GOOD FAITH** ETC **MUST APPLY**; if this ^^ should apply

##### What happens to the sum that is to be paid to the bankruptcy trustee under ss1
- It shall be **==included in the estate of the bankrupt==**


<br>


<br>

#### Extortionate Credit Transactions
##### What is an extortionate cred transaction for the purposes of this section?
- a transaction ==**for or involving provision of [[credit]]**==  <mark style="background: #00FF3E8C;">**to the bankrupt**</mark>  by any person
1. on terms that **==require the bankrupt to make exorbitant payments==** in respect of the credit provided, or
2. which is ==**unconscionable**== under the **principle of law of contracts**

<br>


##### What shall not be regulated for considered as extortionate credit transaction
1. any **debt** extended by a person ==regulated for the provision of Financial services in compliance with the law in ofrce in relation to such debt==

##### Time period for transactions to be extortionate credit transactions?
- It should have been ==**entered into**== within ==**period of 2 years**== ending on the [[#Bankruptcy commencement date]]
##### Order of AA  relating to ECT
1. may **set aside the ==whole or part of any debt created by the transaction==**
2. may ==**vary the terms of the transaction**== or ==**vary the terms on which any security for the purposes of the transaction**== 
3. require any person who ==has been paid **by the bankrupt**== under any transaction, to ==**pay a sum to the bankruptcy trustee;**==
4. require any person to ==**surrender to the BT any property of the bankrupt <u>held as security for the purposes of the transaction</u>**==

###### What happens to the sum or property paid or surrendered to the Bankruptcy trsutee?
- These shall be ==**included in the estate of the bankrupt**==


<br>


<br>

#### OBligations under contracts - s168
##### What can a party to a contract who entered into the same with the bankrupt before the commencement date do?
- He (not being the bankrupt) may **apply to the AA**  for an order
	   1. **==Discharging the obligations of the applicant or the bankrupt==** under the contract, adn
	   2. p==**ayment of damages by the party or the bankrupt for non-performance of the contract or other wise**== <mark style="background: #00FFFE73;">Section 168(2)(b)</mark> 
- Where the damages are payable by the bankrupt under <mark style="background: #00FFFE73;">clause 2b above</mark> , these **shall be provable as [[#Banckruptcy debt]]**

<br>


#### What happens if the bankrupt dies
- The proceedings go on as if he were alive
- The provisions of Chapter 5 relating to administration and distribution of the estate of the bankrupt shall apply to the administration of the estate of the deceased bankrupt
- BT will have **regard to the claims of the legal representatives of the deceased** to payment of **proper funeral and testamentary expenses incurred by them** <mark style="background: #00FFFE73;">section 170(2)</mark> 
	- this claim will <mark style="background: #00FF3E8C;">rank equally to the secured creditors</mark>  under <mark style="background: #00FFFE73;">section 178</mark> 


<br>


<br>

#### Proof of debt
##### By secured creditors - 172
1. where ==**secured creditor**== ==**realises his security**==, he ==**may produce proof of balance due to him**==
2. where the secured creditor **surrenders his security to the BT for the benefit of the creditors**, he ==may **produce proof of his whole claim**==
##### Other creditors - 171
1. First notice will be given to submit proof of debt within 14 days for **==preparing list of creditors==** under [[#Preparation of the List of creditors 132|section 132]] by the [[#“bankruptcy trustee”]]
###### Requirements of proof:
1. creditor to **give ==full particulars of debt==** including the **date on which the debt was contracted** and the **value at which that person assesses it**
2. creditor to give **full creditors of the ==security==** including the **date on which the security was given** and the **value that the person assesses it**
###### If creditor is DECREE HOLDER against the bankrupt?
- **==Then the decree will be proof of debt==**
###### In case bankruptcy debt has NO SPECIFIC VALUE?
- then the [[#“bankruptcy trustee”]] shall **estimate the value**
###### What happens if the BT serves notice and  the person to whom it si served does not file proof of security within 30 days after date of service?
- with the leave of AA, the trustee may **sell or dispose of the property** that **was subject to the security, free of that security**

<br>


#### Mutual credit and Set off
- where before the bankruptcy commencement date, there 
	- have been **mutual dealings between the bankrupt and any creditor,** 
	- the b**==ankruptcy trustee shall take an account of what is due from each party to the other in respect of the mutual dealings==** and 
	- the ==sums due from one party shall be set-off against the sums due from the other and only the balance shall be provable as a bankruptcy debt or as the amount payable to the bankruptcy trustee as part of the estate of the bankrupt.== #important 

<br>

#### What is Distribution of INTERIM DIVIDEND? s174
- This section provides that **==whenever the bankruptcy trustee has sufficient funds in his hand==**, he <mark style="background: #00FF3E8C;">may declare and distribute interim dividend among the creditors in respect of the bankruptcy debts which they have respectively proved.</mark> 

#### When can distribution of property be done? s175
- This section provides that the bankruptcy trustee may, ==**with the approval of the committee of creditor**==s, **<u>divide in its existing form amongst the creditors, according to its estimated value, any property in its existing form which from its peculiar nature or other special circumstances cannot be readily or advantageously sold.</u>**

#### ⭐ Final Dividend - Section 176 
- where the bankruptcy trustee h==**as realised the entire estate of the bankrupt or so much of it as could be realised in the opinion of the bankruptcy trustee**==, he shall give **==notice==** of his 
	1. **intention to declare a final dividend** or 
	2. that **no dividend or further dividend shall be declared.**
> The notice shall require **all claims against the estate of bankrupt** to be **established by a date specified in the notice**

##### Can the AA postpone the final date given in the notice?
- YEs upon **==application of any person interested in the administratio of the estate of the bankrup==**
- After the referred final date, the bankruptcy trustee shall 
	1. **defray any outstanding expenses of the bankruptcy out of the estate of the bankrupt** and 
	2. **if he intends to declare a final dividend, declare and distribute that dividend among the creditors who have proved their debts**, **<u>without regard to the claims of any other persons</u>**. 

##### What happens if a surplus remains after payment in full with interest?
- If a surplus remains after payment in full with interest to all the creditors of the bankrupt and the payment of the expenses of the bankruptcy, the bankrupt shall be entitled to the surplus.

<br>

#### Claims of Creditors 177
##### Can a creditor who has not proved his debt before declaration of any DIVIDEND entitled to disturb the distribution of that dividend or any other divided declared before his debt was proved by reason of fact that he had not participated in the same??
No
###### Exceptions
1. If he <mark style="background: #00FF3E8C;">has proved his debt</mark> , then he ==**shall be entitled to be paid any dividend or dividends**== which he has **faile to receive** ==**out of the money for the time being available for the payment fo any further dvidend**== and
 1. any dividend or dividends payable to him shall be paid before that money is applied to the payment of any such further dividend.

##### What if bankruptcy trustee refuses to pay a divided that is payable under ss1?
- then, the AA may order him to 
	1. ==**pay the dividence**== and
	2. ==**pay out of his own money**== -> **interest on the divided**, and **costs of the proceedings in which the order to pay was made**


<br>

####  Priority of payment of debts - s178
1. firstly costs and expenses incurred by the bankruptcy trusty for the bankruptcy process in full
2. secondly
	1. the workmen’s dues for the period of twenty-four months preceding the bankruptcy commencement date;
	2. debts owed to secured creditors
3. thirdly, wages and any unpaid dues owed to employees, other than workmen, of the bankrupt for the period of twelve months preceding the bankruptcy commencement date;
4. (d) fourthly, any **amount due to the Central Government and the State Government**including the ==**amount to be received on account of Consolidated Fund of India and the Consolidated Fund of a State, if any**==, in respect of the whole or any part of the period of two years preceding the bankruptcy commencement date;
5. Lastly all other debts and dues owed by the bankrupt **including unsecured debts.**
##### What happens to the surplus if remaining?
- This will become ==**interest payments on the debts**== in respect of the ==**period during which they have been outstanding since the**== **[[#Bankruptcy commencement date]]**
- These payments will rank equally
##### How shall unsecured creditors rank?
- equally, ***unless otherwise agreed contractually by such creditors***

---
### Ch 6: Adjudicating authority for Individuals and Partnership firms (179-183)

- The Adjudicating Authority, in relation to insolvency matters of individuals and firms shall be the **==Debt Recovery Tribunal==** having territorial jurisdiction over the place where the individual debtor actually and voluntarily resides or carries on business or personally works for gain and can entertain an application under this Code regarding such person. <mark style="background: #00FFFE73;">179</mark> 

<br>


- no civil court or authority shall have jurisdiction to entertain any suit or proceedings in respect of any matter on which the Debt Recovery Tribunal or the Debt Recovery Appellate Tribunal has jurisdiction under this Code. No injunction shall be granted by any court, tribunal or authority in respect of any action taken, or to be taken, in pursuance of any power conferred on the Debt Recovery Tribunal or the Debt Recovery Appellate Tribunal by or under this Code. <mark style="background: #00FFFE73;">180</mark> 

<br>

- An a**ppeal from an order of the Debt Recovery Tribunal under this Code** shall be filed **==within thirty days==** <mark style="background: #D2B3FFA6;">before the Debt Recovery Appellate Tribunal</mark> . 
	- The Debt Recovery Appellate Tribunal may, **if it is satisfied that a person was prevented by sufficient cause from filing an appeal within thirty days**, ==**allow the appeal to be filed within a further period not exceeding fifteen days.**== <mark style="background: #00FFFE73;">181</mark> 

<br>

- This section provides that an **==appeal from an order of the Debt Recovery Appellate Tribunal==** on a <mark style="background: #D2B3FFA6;">question of law under this Code</mark> shall be filed ==**within forty-five days**== <mark style="background: #D2B3FFA6;">before the Supreme Court.</mark> The Supreme Court may, if it is satisfied that a person was prevented by sufficient cause from filing an appeal within forty-five days, allow the appeal to be filed within a further period not exceeding fifteen days. <mark style="background: #00FFFE73;">182</mark> 

<br>

- This section provides that where an **application is not disposed of or order is not passed within the period specified in this Code,** the D==ebt Recovery Tribunal or the Debt Recovery Appellate Tribunal, shall record the reasons for not doing so within the period so specified;== and the **<mark style="background: #D2B3FFA6;">Chairperson of the Debt Recovery Appellate Tribunal, after taking into account the reasons so recorded, extend the period specified in this Code, but not exceeding ten days.</mark> ** <mark style="background: #00FFFE73;">183</mark> 

---
### Ch 7: Offences and Penalties (184-187)

#### If creditor gives false information in isnolvenncy process? 184
- Imrpisonment ==** extend to one yaer**==
- or with fine upto ==**5 lakh rupees**==

<br>


#### For contravention of provisions 185
- If an **[[#Resolution professional]]** ==**deliberately contravenes provisions of this party**==, then->
	1. imprisionment ==extenging to **6 months**== or
	2. **fine** ==**up to 15 lakh**== but ==**less than 1 lakh**==


<br>

<br>


#### Concelment and false information by bankrupt 186
##### wilful omission and concealment
>If the bankrupt knowingly makes a ==false representation== or ==**willfully omits or conceals any material information**== while making an application for bankruptcy under section 122 or while providing any information during the bankruptcy process,

1. ==**Imrpisonment up to 6 months**==
2. or with fine up to ==**5 lakh**==

<br>


##### Fraudulently failed ot provide or deliberately withheld the poduction of, destroyed, falsified, or alterd books of accnt, financial information, and other records under his control
1. Imprisonment -> **upto 1 year**
2. or writh **fine** up to ==**5 lakh**==
<br>

##### Contravened restrictions under s140 or 141
>Meaning he did somethin he was disqualifed from doing or acted in contravention of th erestrictions imposed

- Imprisonemnt -> 6 montth
- or fine up to **5 lakh rupees**

<br>

##### Failed to deliver possession of any property comprised in the estate of the bankrupt which hw is required to deliver  under Section 156
![[#The Bankrupt his banker his agent must shall deliver the property and docs to the Bankruptcy trustee - Section 156]]

- Imprisonment up to ==**6 months**==
-  or fine -> up to ==**5 lakh**==
- or both


<br>

##### if bankrupt fails to account without any reasonable cause or satisfactory explanation for any loss incurred of any substantial part of his property comprised in the estate of bankrupt -> 12 months before filing of the bankruptcy application
- Imprisonment  up to ==**2 years**==
- or fine -> may extend to ==**3 times of the value of loss**== or
- both

> - where such loss is not quantifiable, the total amount of fine imposed shall not exceed five lakh rupees


<br>

#### Punishment for certain actions - 187
> - Where [[#“bankruptcy trustee”]] 
> 	1. fraudulently misapplied, retained or accounted for any money or property comprised in the estate of the bankrup
> 	2. wilfully acted in a manner that the estate of the bankrupt has suffered any loss in consequence of breach of any duty of the bankruptcy trustee in carrying out his functions under section 149 -> [[#What are functions of Bankrptcy Trustee 149|see here]]


- Imprisonment ==**3 years**== or 
- ==**fine not less than 3 times the amount of the loss caused**== or likely to have been caused
	- if not quantifiable -> fine **lesser than 5 lakh rupees**

> Provided further that the bankruptcy trustee shall not be liable under this section if he
seizes or disposes of any property which is not comprised in the estate of the bankrupt and at
that time had reasonable grounds to believe that he is entitled to seize or dispose that property.

<br>

#### sECTION 235A - where there is no specific penalty or punishment

> [!NOTE] WHERE NO SPECIFIC PENALTY OR PUNISHMENT IS PROVIDED
> 
> 
> 
> - If any personcontravenes any of the provisions of this Code or the rules or regulations made thereunder for which ==**no penalty or punishment is provided in this Code**==, such person => shall be punishable with <mark style="background: #FF4E00A6;">fine which shall not be less than one lakh rupees but which may extend to two crore rupees.</mark> ]
> 
> 




<br>

---

#### Code of Conduct for insolvency professionals - section 208
1. (a) to take ==**reasonable care and diligence while performing his duties**==;
2. (b) to **==comply with all requirements and terms and conditions specified in the bye-laws of the insolvency professional agency of which he is a member;==**
3. (c) to **<u>allow the insolvency professional agency to inspect his records;</u>**
4. (d) to ==submit a copy of the records of every proceeding before the Adjudicating Authority to the Board as well as to the insolvency professional agency== of which he is a member; and
5. (e) to perform his functions in such manner and subject to such conditions as maybe specified.