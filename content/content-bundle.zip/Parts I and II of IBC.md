
---
up:: [[📚 IBC Repository]]
cssclass: 
embedded-title: false

---

# Parts I and II of IBC

```toc
```

> ### Important terms
> - **Insolvency_ is a financial situation, where an entity or an individual is unable to meet the financial obligations due to excess of liabilities over assets**, whereas 
> - **_Bankruptcy_ is a legal procedure where the court of law passes orders with respect to insolvency of an individual or entity and consequently passes orders for its resolution. Thus, an individual or an entity can be insolvent without being bankrupt and insolvency can lead to bankruptcy if the insolvent individual or entity is unable to overcome the financial catastrophe.**
> - Liquidation  is **the ==process of bringing a business to an end and distributing its assets to claimant==s**

> ### Resolution vs Liquidation
> #### Resolution
> - Resolution refers to a plan proposed by any authorised person/entity for enabling the overdue payments of a corporate debtor through restructuring or through part payments, while allowing the corporate debtor to continue as a going concern.
> #### Liquidation
> - Liquidation is the winding up of a corporation or incorporated entity under the supervision of a person or “liquidator”, empowered under law for such operation and for distribution of proceeds to the various creditors as per an agreed formula. Only firms can be liquidated. Defaulting individuals cannot be liquidated.
> 	- he code therefore does not allow liquidation of a firm directly.
> 
> ![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan#Difference between liquidation and IRP when it comes to defining what is the best solutino]]
> 





---
# Overview
## Introduction
- Object of the Act: consolidate and amend laws relating to **reorganisation and insolvency resolution** in a **time-bound manner**of corporate persons partnerhsip firms and individuals; for ==**maximisation of value of assets of such persons**==, ot **promote entrepreneuship**, availability of credit, and ==balance the **interesets of all stakeholders**== 
- The bankruptcy code is a one stop solution for resolving insolvencies, which previously was a long process that did not offer an economically viable arrangement. The code aims to protect the interests of small investors and make the process of doing business less cumbersome. The IBC has 255 sections and 11 Schedules.

<br>

- The Code outlines **separate insolvency resolution processes for ==individuals==**, ==**companies**== and ==**partnership firms**==. The process may be initiated by either the debtor or the creditors. 
- A maximum time limit, for completion of the insolvency resolution process, has been set for corporates and individuals. 
	1. For companies, the process will have to be completed in 180 days, which may be extended by 90 days, if a majority of the creditors agree. 
	2. For start ups (other than partnership firms), small companies and other companies (with asset less than Rs. 1 crore), resolution process would be completed within 90 days of initiation of request which may be extended by 45 days


<br>



-   Insolvency and Bankruptcy Code was enacted to strike a balance between Resolution and liquidation.
-   ==**Creditors of a sinking company should first explore the option to revive the potentially viable company. Where revival or resolution is not feasible, then they should go for liquidation.**==
-   In case, a business attains resolution, the creditors will have the option to recover their dues from future earning of the company. In the contrary, liquidation is the drastic solution.<mark style="background: #FF5582A6;"> Liquidation brings the life of a firm to an end.
</mark> 
-   Revival of the stressed company may be the primary objective of the Code, but official data show that more companies have gone for liquidation in the new regime so far than the resolution as lenders have failed to endorse any viable plan for their revival. According to the data available on the IBBI website, till the end of June 2018, total 1547 applications for the Insolvency Resolution were filed out of which 977 applications had been admitted into resolution process and of which 91 were closed on appeal or review. Data further reveals that till 30th June 2018, total 136 companies yielded liquidations while only 34 companies achieved resolution
---
## Scheme of the Code
![[IBC.png]]

---
# Notes
## Part I
### Definitions
#### To whom does the provision apply? s2
1. any company under Companies act 2013 or previous copmany laws
2. companies governed by **any special act** unless the provisions are **inconsistent with the provisions of this Act**
3. LLP incorporated under LLP Act of 2008
4. other incorporated body under any law in force as notified by Central govt
5. **personal guarantors to corporate debtors**
6. **partnership firms** adn **proprietor ship firms**
7. **individuals** <mark style="background: #FF0000A3;">other than persons referred to in **clause e**</mark> i.e *personal guarantors to cor debtors*


<br>

#### What is a claim? s3(6)
1. right to payment 
2. right to **remedy** fo r**breach of contract** under any law in force if such **breach gives rise to a right to payment**

> these apply **whether or not such right is reduced to judgement, fixed, matured, unmatured, disputed, undisputed, secured, or unsecured**


<br>



#### Who is a "corporate debtor"? s3(8)
- [[#Who is a corporate person s3 7|corporate person]] who ==**owes a debt to any person**==
#### Who is a corporate person? s3(7)
1. company under **section 2(20) of companies Act**
2. LLP under **section 2(1) of the LLP Act**
3. any other person **incorporated** with **limited liability** under any law for the time being in force
4. **shall not include any [[financial service provider]]** 🔴
#### Who is a creditor? 3(10)
- Any person **to whom debt is owed**
- It includes
	- **[[financial creditor]]**
	- [[operational creditor]]

#### Debt? 3(11)
- **==liabilityor obligation==** in respect of a claim **due from any person**; 
- it includes
	- **[[financial debt]]** and
	- **[[operational debt]]**
#### Default 3(12)
(12) “default” means non-payment of debt when whole or any part or instalment of the amount of debt has become due and payable and is not Paid by the debtor or the corporate debtor, as the case may be;

<br>

#### Secured creditor 3(30)
- Person in favour of whom **[[secured interest ]]** is created


----
## Part II - INSOLVENCY RESOLUTION AND LIQUIDATION FOR CORPORATE PERSONS
### When does the part apply?
- Applies to matters relating to **==insolvency and liquidation==** of [[#Who is a corporate debtor s3 8|corporate debtors]] where the ==**minimum amount of default**== is **==one crore rupees==** #important 

<br>


### Important Definitions for Part II (Section 5)
#### Who is the adjudicating authority fo rthis part??
- The **NCLT** under **section 408 of companies Act**
#### Base Resolution plan 5(2A)
- Resolution **Plan** that is **provided by [[#Who is a corporate debtor s3 8|corporate debtor]]** under **<mark style="background: #00FFFE73;">Section 54A of IBC</mark> **


<br>

#### Board
(1) “Board” means the Insolvency and Bankruptcy Board of India established under sub-section (1)


<br>



#### Who is corporate applicant? 5(5)
1. a **[[#Who is a corporate debtor s3 8|corp debtor]]**
2. **==member/partner==** of the corporate debtor who is **authorites to make application** for CIRP or **[[pre-packaged insolvency resolution process]]**  underthe **constitutional doc of the corporate debtor**
3. person who has **control and supervision** over the **financial affairs of the corporate debtor**

#### Corporate guarantor 5(5A)
- [[#Who is a corporate person s3 7|corporate person]] who is the ==**surety in a contract of guarantee**== to a [[#Who is a corporate debtor s3 8|corporate debtor]]

#### Dispute 5(6)
- It **includes suit** or **arbitration proceedings** that relate to 
	![[Day 1 - IBC.png]]

<br>

#### Financial creditor
![[financial creditor]]

<br>


#### Financial debt
![[financial debt]]


<br>

#### Information memorandum
- 5(10) “information memoRP randum” means a ==**memorandum prepared by resolution professional under sub-section (1) of section 29;**==

>- Acc to [[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan]]:
>	- Resolution professiona must **provide the most update info** about the entity as **accurately as possible**; RP has to be able to **verify claims to liabilities as well s the assets disclosed by the entity**;  
>	- This info -> used to ==**compile informaiton memorandum**==

<br>


#### Information Utility
- means a person who is registered with the Board as an information utility under section 210;
>IUs are entities that would act as data repositories of financial information which would receive, authenticate, maintain and deliver financial information pertaining to a debtor with a view to facilitate the insolvency resolution process in a time-bound manner.

![[information utility (IBC)]]
<br>


#### Initiation date and insolvency commencement date
![[Day 1 - IBC-1.png]]

<br>

#### Insolvency resolution Process period (14)
- Period of **==180 days==** from the beginning of the [[#Initiation date and insolvency commencement date|Insolvency commencment date]] and **ending on** the 180th day

<br>


#### Liquidation Cost (16)
(16) "liquidation cost" means **==any cost incurred by the liquidator==** ==**during the period of liquidation**== subject to such regulations, as may be specified by the Board;
#### Liquidation Commencment date (17)
"liquidation commencement date" means the **==date on which proceedings for liquidation commence==** in accordance with<mark style="background: #00FFFE73;"> section 33 or section 59</mark> , as the case may be;
#### Liquidator (18)
#important  
(18) "liquidator" means an insolvency professional appointed as a liquidator in accordance with the provisions of Chapter III or Chapter V of this Part, as the case may be;

<br>

#### Officer (19) 
- Purpposes of **chpater VI and VII of this part** -> and **officer who is in default** as defined under Section 2(60) of CA, or a **designator partner** as defined under section 2(j) of LLP Act


<br>

#### Operational creditor  (20)
![[operational creditor]]

#### Operational debt (21)
![[operational debt]]


<br>

#### Personal Guarantor
- **==Individual==** who is the **surety** in a a**contract** **to a [[#Who is a corporate debtor s3 8|corporate debtor]]**

#### Personnel 
- **dirctorsk, managers**, **key manegerial personnel, designated partners, and employees** of the corporate ddebtor


<br>

#### pre-packaged insolvency commencement date,  pre-packaged insolvency resolution process costs, "pre-packaged insolvency resolution process period"
![[Day 1 - IBC-2.png]]

<br>


#### Related party 

##### Who is related party in relation to corporate debtor?
<mark style="background: #00FFFE73;">clause 24</mark> 
- (a) a **director or partner of the corporate debtor or a relative of a director or partner of the corporate debt**or;
- (b) a k**ey managerial personnel of the corporate debto**r or a **relative of a key managerial personnel** of the corporate debtor;
- (c) a limited liability partnership or a partnership firm in which a director, partner, or manager of the corporate debtor or his relative is a partner;
- (d) a private company in which a director, partner or manager of the corporate debtor is a director and holds along with his relatives, more than two per cent. of its share capital;
- (e) a public company in which a director, partner or manager of the corporate debtor is a director and holds along with relatives, more than two per cent. of its paid-up share capital;
- (f) any body corporate whose board of directors, managing director or manager, in the ordinary course of business, acts on the advice, directions or instructions of a director, partner or manager of the corporate debtor;
- (g) any limited liability partnership or a partnership firm whose partners or employees in the ordinary course of business, acts on the advice, directions or instructions of a director, partner or manager of the corporate debtor;
- (h) any person on whose advice, directions or instructions, a director, partner or manager of the corporate debtor is accustomed to act;
- (i) a body corporate which is a holding, subsidiary or an associate company of the corporate debtor, or a subsidiary of a holding company to which the corporate debtor is a subsidiary;
- (j) any person who controls more than twenty per cent. of voting rights in the corporate debtor on account of ownership or a voting agreement;
- (k) any person in whom the corporate debtor controls more than twenty per cent. of voting rights on account of ownership or a voting agreement;
- (l) any person who can control the composition of the board of directors or corresponding governing body of the corporate debtor;
- (m) any person who is associated with the corporate debtor on account of—
	- (i) participation in policy making processes of the corporate debtor; or
	- (ii) having more than two directors in common between the corporate debtor and such
	- person; or
	- (iii) interchange of managerial personnel between the corporate debtor and such person;
	- or
	- (iv) provision of essential technical information to, or from, the corporate debtor;

##### Whois related party in relation to an individual?
- (a) a person who is a relative of the individual or a relative of the spouse of the individual;
- (b) a partner of a limited liability partnership, or a limited liability partnership or a partnership firm, in which the individual is a partner;
- (c) a person who is a trustee of a trust in which the beneficiary of the trust includes the individual, or the terms of the trust confers a power on the trustee which may be exercised for the benefit of the individual;
- (d) a private company in which the individual is a director and holds along with his relatives, more than two per cent. of its share capital;
- (e) a public company in which the individual is a director and holds along with relatives, more than two per cent. of its paid-up share capital;
- (f) a body corporate whose board of directors, managing director or manager, in the ordinary course of business, acts on the advice, directions or instructions of the individual; 
- (g) a limited liability partnership or a partnership firm whose partners or employees in the ordinary course of business, act on the advice, directions or instructions of the individual; 
- (h) a person on whose advice, directions or instructions, the individual is accustomed to act;
- (i) a company, where the individual or the individual along with its related party, own more than fifty per cent. of the share capital of the company or controls the appointment of the board of directors of the company.

##### Who is a relative underthis clause?
- (i) members of a Hindu Undivided Family,
- (ii) husband,
- (iii) wife,
- (iv) father,
- (v) mother,
- (vi) son,
- (vii) daughter,
- (viii) son’s daughter and son,
- (ix) daughter’s daughter and son,
- (x) grandson’s daughter and son,
- (xi) granddaughter’s daughter and son,
- (xii) brother,
- (xiii) sister,
- (xiv) brother’s son and daughter,
- (xv) sister’s son and daughter,
- (xvi) father’s father and mother,
- (xvii) mother’s father and mother,
- (xviii) father’s brother and sister,
- (xix) mother’s brother and sister, and

>Wherever the **relation is that**of a **son, duaghter, sister or brother**, ==**their spouses shall also be included**==


<br>


<br>

#### Resolution applicant 
- Perosn who **submits resolution plan to resolution professional**
#### Resolution plan
- Plan proposed by any person for **==insolvency resolution of the corp debtor==** as a going concern in acc with Part II
#### Resolution professional
- **==Involvency professional==** who is **appointed to ==conduct CIRP==**;
	- alos ***includes interip Resolution professional**

<br>

#### Voting share
- the ==**share of voting rights of a single [[financial creditor]]**== in the **==committee of creditors==**

----

### Chapter 2: CIRP (6-32A)
[[CORPORATE INSOLVENCY RESOLUTION PROCESS.png]]
![[CORPORATE INSOLVENCY RESOLUTION PROCESS.png]]




#### Who can initiate CIRP against corporate debtor? s6
1. [[financial creditor]]
	- how? <mark style="background: #00FFFE73;">**Section 7**</mark> 
		1. either by himself or jointly -> ==**files an application in prescribed manner**==; pays prescribed fee **before the ==adjudicating authority==**
		2. He will funish
			1. record of default recorded with the information utility or any evidence of default
			2. the **name of resolution  professional** who will **act as interim resolutional prof**
				>  ***⚖️ Noor Alam & Ors vs Prism Infracon Litd.*** : *while admitting an application under section 7, the AA shoudl be **satisfied that there is no disciplinary proceeding pending against the insolvency professional** *
			3. other specified information
		3. Adjudicating authority -> within ==**14 day**== ascertains eistence fo default from **furnished records**
			- if satisfied 🟢 that **default has occurred** and that the **filed application is comlete** and that there are **no disciplinary proceedings against pending resolution**, the resolution <mark style="background: #00FF3E8C;">will be **admitted**</mark> 
				- if there is **defect 🔴**, notive of ==**7 days**== will be given to **rectify the defect**
				>***⚖️ Surendra Trading Company vs Juddilal Kamlapat Jute Mills Company Ltd***: *The time limit of **7 days** for for removal of defects is ==directory and **not mandatory**==*
			- If 
				- <mark style="background: #00FF3E8C;">affirmed</mark>  -> order to be communicated to [[financial creditor]] and [[#Who is a corporate debtor s3 8|corporate debtor]] within 7 days
2. [[operational creditor]] 
	- How? 
		1. **INITIAL NOTICE** <mark style="background: #00FFFE73;">**section 8**</mark> 
			1. may **deliver demand notice of unpaid operational debtor ==copy of an invoice dmanding payment of amount involved in the default==** to the corporate debtor
			2. Corp debtor **shall** within ==**10 days of receipt fo demand notice/copy of invoice**== bring to notice of operation creditor
				1. **existing disute**
				2. **pending suit or arbitration proceedings** that were **filed <u>before receipt of notice or invoice</u>**
				3. **repayment of operational debt** either by *sending attested copy of record of electronic transfer of unpaid amounted* or by sending *attested copy of record of an encashed cheque*
			> ***⚖️ Prajna Prakash Nayak vs ASAP Info Systems Pvt Ltd***: *Issuance of notice under section 8 is **not a mere formality** and  ==**is mandatory**==* 
		2. **APPLICATION FOR INITIATION** after expiry of time period <mark style="background: #00FFFE73;">**Section 9**</mark> 
			- if he **does not receive payment or notice**, he may **==file application==** for ==**initiating CIRP**==
				- will furnish
					- demand notice given to cop debto
					- ==**affidavit**== that the debor has **not given any notice r/lating to a dispute of the unpaid operational debt**
					- copy of **certificate** form the financial institution 
			- operational creditor initiating a corporate insolvency resolution process **may propose a resolution professional to act as an interim resolution professional.**
			- The Adjudicating Authority shall admit the application within fourteen days and communicate it to both the operational creditor and the corporate debtor if:
				1. application is complete
				2. ther is **no repayment of the unpaid operational debt**
				3. invoice or notice for payment has been deliveredby operational creditor
				4. no notice of dispute has been **received by the operation credtor**; there is **no record of dispute in information utility**
				5. ther is **no disciplinary action against dispute resolution professinal**
			- Adj authority **shall reject application** if the above 5 points are mentioned; however, ==**before rejecting**, a **notice to applicant shall be given to rectify defect** within **7 days**==
3. [[#Who is a corporate debtor s3 8|Corporate debtor]]
	- [[#Who is corporate applicant 5 5|corp applicant]] <mark style="background: #00FFFE73;">section 10</mark> 
		- Upon comission of default by **corporate debot**, cop applicant **may file application to initiate CIRP**
		- Corp Applicant will furnish following info
			1. **==account books and othe rspecified docs==**
			2. <mark style="background: #00FF3E8C;">resolution professional proposed to be appointed</mark> as INterim rp
		- AA -> w/in **14 days** shall **reject or admit**
			- before rejection 🔴 -> **==7 day notice to be given to rectify defects==**


<br>

#### Who CANNOT MAKE APPLICATION? - Section 11
1. **Corpote debtor**  ==**undergoing CIRP**==
2. Corp debot who has **completed CIRP**   ==**12 months before making th eapplication**==
3. Corp debtor or financial creditor who has **==violated any terms of reoslution plan which was apporved 12 months before making of application==**
4. corp debtor in respect of whome a **==liquidation order hsa been made==**

>Explanation 2 provides that **nothing in this section will prevent** a **corporate debtor** in above 4 clauss **==from initiating cirp==** against ==**another Corporate debtor**==

>***⚖️ Jai Ambe Enterprise vs SN Plumbing Pvt. Ltd.*** :  ==**two parallel insolvency proceedings**== **cannot run** against a corporate debtor

<br>

#### Time limit for completition of IRP? 12
- Within ==**180 days**== for ==**date of admission of application to initiate such process**==
- Resolutional Professionsl -> will file **application** to AA beyond the 180 day period if he has been **instructed to do so** by the **==**committe of creditors**== by a vote of **==66%==**
	- if AA satisfied that CIRP is of nature that it **cannot be completed in 180 days**, then AA may **extend the duration of such process beyond 180 days** but ***not exceeding 90***
- ***Extensions cannot be granted more than once***

##### Mandatory completion?
- CIRP -> mandatorily completed **within ==330 days from insolvency commendment date==** which will be inclusive of **extension periods granted**

<br>


#### Can application under sections  7, 9 and 10 be withdrawn? S12
- Yes upon application made by applicant with ==**approval of 90% voting share of committee of creditors**==


<br>

#### Moratorium
>Moratorium to be followd by **public announcement of insolvency process**


![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan#Moratorium period]]
- S 13
	1. For appplication under <mark style="background: #00FFFE73;">Sections 7 9 and 10</mark>; AA **shall declare a morarium for purposes of s14**
	2. it shall **cause a public announcement of CIRP** and call for submissions to be made under **section 15** (made immediately after appointment of IRP)
	3. AA shall **appoint Interim Resolution Profession** as laid down under s16
- **<mark style="background: #00FFFE73;">S14</mark> ** 
	- Moratorium shall be instituted for 
		1. prohibiting **institution of suits** or **continuation of pending ones ==against corp debtor==** including the **exueciton fo any judgement, decree order**
		2. (b) ==transferring, encumbering, alienating or disposing of by the **corporate debtor**== any of its assets or any legal right or beneficial interest therein;
		3. (c) any **action to foreclose, recover or enforce any security interest created by the corporate debtor w.r.t. its property including** any action under the Securitisation and Reconstruction of Financial Assets and Enforcement of Security Interest Act, 2002
		4. (d) the recovery of any property by an owner or lessor where such property is occupied by or in the possession of the corporate debtor.
	- <mark style="background: #00FF3E8C;">Supply of **essential goods or services to the debotr** will **<u>not be terminated/interrupted/supended</u> during moratorium**</mark> 
##### When does moratorium end?
- Upon submission of resolution plan

<br>

#### Appointement of Interim RP s16
- TO be appointed on [[#Initiation date and insolvency commencement date|insolvency commencment date]] i.e. on date of admission of application
- Wher application is made by 
	1. ==**financial creditor**== or **==corporate debtor==**, the RP that is proposed in section <mark style="background: #00FFFE73;">7 or 10</mark>  shall be appointed provided **there are no disciplplinary proceedings against him**
	2. **==Operational creditor==**
		- if no application made, -> reference to teh **==BOARD==**; baord shall w/in **==10 days==** **recoment neame of the IP** ot AA; this IP's <mark style="background: #FF4E00A6;">term  in this case will **not exceed 30 days**</mark> 

> ###### **Can an ex employee of the Financial creditor be employed as IRP?**
> - No *(⚖️ **State Bank of India vs Metenere Ltd**)*


<br>


<br>


#### Management of affairs of corporate debtor by interim resolution professional s17
- **==powers of the board of directors or the partners of the corporate debtor shall be suspended== and be exercised by the interim resolution professional.** 
- The officers of the corporate debtor shall report to the interim resolution professional and shall provide him access to required documents and records of the corporate debtor.
- The financial institutions maintaining accounts of the corporate debtor shall act on the instructions of the interim resolution professional and furnish all available information of the corporate debtor to the interim resolution professional.
##### Powers of IRP? s17
1. (a) ==**act and execute in the name and on behalf of the corporate debtor all deeds, receipts, and other documents;**==
2. (b) ==**take actions as specified by the Board;**==
3. (c) authority to access the electronic financial records of corporate debtor from information utility;
4. (d) authority to access the books of account, records, etc of corporate debtor available with government authorities, statutory auditors, accountants and such other persons.
##### Duties s18
1. (a) Collect ***business operations and financial and operational payments for the previous two years, list of assets and liabilities as on the initiation date and all such information relating to the assets, finances and operations of the corporate debtor*** ==**for determining his/her financial position.**==
2. (b) In accordance with sections 13 and 15, ==**receive and collate all the claims submitted by creditors to him.**==
3. (c) Tak**e control and custody of any asset over which the corporate debtor has ownership rights which may be located in a foreign country or may not be in corporate debtor's possession** or **of movable or immovable tangible assets or of intangible assets including intellectual property, of securities including shares held in any subsidiary of the corporate debtor, financial instruments or insurance policies, assets that are subject to the determination of ownership by a court or authority or such other duties as specified by the Board.**

>interim resolution professional **should** make every endeavour to **protect and preserve the value of the property of the corporate debtor** and manage the operations of the corporate debtor as a going concern.
>
> For the same, the interim resolution professional should -
> - (a) Appoint accountants, legal or other professionals as necessary;
> - (b) Enter into contracts or amend or modify the contracts or transactions;
> - (c) Raise interim finance, making sure that no security interest shall be created over any encumbered property and if such property is of not less than the amount equivalent to twice the amount of the debt, than, a prior consent of the creditors whose debt is secured over such encumbered property shall be taken.
> - (d) Issue instructions to personnel for keeping the corporate debtor as a going concern and take all such other necessary actions.

<br>


#### Personnel of the corporate debtor to extend cooperation to IRP
- ==**Personnel fo the CD, its promoters, and other persons associated with the manageent of the CD**== **shall extend all assistance and cooperation to the IRP** as may be required by the IRP
##### What if such personnel refuses to cooperate?
- Then the IRP may ==**make an application to the AA for necessary directions**==
	- the A will then by an order **==direct such personnel or other person to comly with the instructions of the resolution professional==** an to **cooperate with him in collection of information and management of the CD**

<br>


<br>

#### Committee of Creditors s21
- **After collation of all claims and after determination** of the **financial position of the corporate debto**r, the interim resolution professional **==shall constitute a committee of creditors==**, such committee of creditors shall ==**comprise of all financial creditors of the corporate debtor.**==
- Any person who is both a financial creditor and an operational creditor, his capacity as a financial creditor and his voting share proportionate shall be to an extent of his financial debt owed by the corporate debtor. Such person's capacity as an operational creditor shall be to an extent of his operational debt.
- ==**All decisions of the committee of creditors**== shall be taken by a **==vote of not less than seventy-five percent of voting share of the financial creditors==** *<u>unless otherwise provided</u>*
	- The committee of creditors shall have the right to require the resolution professional at any time during the corporate insolvency resolution process. 
	- Any financial information so required by the committee of creditors shall be made available by the resolution professional within seven days.

> ![[Day 2  IBC#⚖️ Kalpraj Dharamshi Anr vs Kotak Investment Advisors Ltd Anr]]

##### What is the required voting share of CoC for the decisions taken by th e committee? section 21(8)
- Atleast  ==**51 percent of the voting share of financial creditors**==
##### Does the CoC have the right to requrie the Resolution professional to furnish any financial info in r/lation to the corporate debtor? section 21(9)
- YES
###### In what durationwill the resolution professional be requried to submit info requried by the Coc?
- Within 7 days of such requisition
<br>


##### What if the Creditor is a related party of the coprorate debtor?
- Then **no right of representatin, participation, or voting in the meetin**
	- who is a -> [[#Related party]]
##### What if corporate debtor owes financial debts to two or more financial creditors as part of a consortium or agreement?
- Then **==each such financial creditor==** -> shall be **part of the CoC** and ==**their voting share shall be determined on the basis of the financial debts owed to them**==
##### What if a person is a financial creditor AND an operational creditor s21(4)
- He shall be 
	1. **considered as financial creditor** to the **extent of the [[financial debt]]** that is **owed by the Corporate debotr**; he shall be included in the CoC with **voting share that is ==proportionate to the extent fo the financial debts owed to him==**
	2. he shall be considered as an operation creditor **to the extend of the operational debt owed by the CD to him**
##### What if the operational creditor has assigned or legally trnasferred any operational debt to a financial creditor?
- THe assignee or transferree **shall be considered as an operational creditor ==to the extend of such assignment or legal transfer==** 


<br>


##### What if the terms of the financial debt extended to AS PART OF A CONSORTIUM ARRANGEMENT OR SYNDICATED FACILITY provides for a single trustee/agent to act for alll financial creditor? section 21(6)(6)
#important  <mark style="background: #00FFFE73;">sub section 6 of section 21</mark> 
- In such case, **each financial creditor** may 
	1. **authories the trustee or agent** to ==**act on his behalf in the CoC**== to the **==extent of his voting share==**
	2. to **represent himself** in the **coc** to the **extent  of his voting share**
	3. may **appoint an insolvency professional** at his **own cost** to ==represent himself in the COC== to the **extent of his voting share**, or
	4.  exercise his right to vote to the extent of his voting share with one or more financial creditors jointly or severally

##### What if the financial ddebt is in the form of securites or deposits, and the terms of the financial debt providefor appointment of a trustee or agent to act as authorised represetnative for all financial creditos? section 21(6A)(a)
- Then, **such trustee or agent ==shall act on behalf of such financial creditor==**

##### What if financial debt is owed to a class fo creditors exceeding the number as may be specifed (other than the creditors above)? section 21(6A)(b)
- Then, the **interim resolution professional** shall ==**make application ot he AA**== along with the **list of all financial creditors** ==containing the **name of the insolvency professional== ***other than the interim resolution professional*** to <mark style="background: #00FF3E8C;">act as their authorised representative</mark>; **such representative shall be ==appointed by the Adjudicating authority prior to the first meeting of the COC==** 
##### What if the financial  debt is represented by a guardian, executor or administrator? section 21(6A)(c)
- Then **such person** ==**shall act as authorised representative on behalf of such financial creditors**==

<br>


##### How will these representatives be remunerated? section 21(6B)
- in terms of <mark style="background: #00FFFE73;">clauses a and c of 6A</mark> , it will be in terms of the the financial debt or other relevant considerations
- under clause b, it shall be **as specified which shall form part of the IRP costs**
##### Who will decide the manner of voting and determination of the voting share in respect of financial debts under sections 21(6) and section 21(6A)?
- By the Board






<br>


<br>


<br>


#### Appointment of Resolution Prof s22
- First meeting of the committee of creditors shall be held within seven days of its constitution. 
- Where by a ==**majority vote of not less than seventy-five percent of the voting share, the financial creditors shall either appoint the interim resolution professional as a resolution professional or replace the interim resolution professional.**== 
- If appointed, the committee shall communicate its decision to the interim resolution professional, the corporate debtor and the Adjudicating Authority and **if replaced it shall file an application before the Adjudicating Authority for the appointment of the proposed resolution professional.** 
	- The A**djudicating Authority shall forward the name to the Board and shall appoint the same if confirmed by the Board.** 
		- *==If the Board does not confirm the name of the proposed resolution professional within ten days, the Adjudicating Authority shall direct the interim resolution professional to continue to function until the Board confirms the proposed appointment.==*
#### RP to conduct CIRP Resolution process s23
- the resolution professional shall along with conduction the corporate insolvency process ==shall also manage operations as the corporate debtor.==  #important
- The ==powers and duties vested upon a resolution professional shall be same as of interim resolution professional==. The interim resolution professional shall provide all the information, documents and records pertaining to the corporate debtor in his possession and knowledge to the resolution professional.
#### RP to conduct meetings of Committee of creditors
##### Notice of such meetings
- to be given by RP to 
	1. members of committee of creditors
	2. members fo the **suspended Bod** or the **partners fo cop persons**
	3. **operational creditors** or their representitive **<u>if the aggregate of their dues is not less than 10 %of the debt</u>
	4. **; thus their debt has to be 10% or more of the operational debt ?**
##### Does absence of directork/partner/representative of Operational creditros invalidate proceedings of the meeting? 
- no

##### Who decides the voting share to be assigned to each creditor in the manner specified by the Board?
- ==**The Resolution professional**== 





<br>

<br>



<br>


<br>


#### Duty of Resolution Professional 🔴
1. **protect and preserve** the **assets fo the corporatae debtor** including the **continued business operations fo CD**
	- For above purpose, it shall
		1. **take immediate custody** of the **assets fo the corporate debtor** inclduing the it's business records
		2. **represent and act on behalf of CD** with **third parties**; exercise **rights for the benefit fo CD in judicial quasi judicial or arbitration proceedings**
		3. (c) raise interim finances subject to the approval of the committee of creditors;
		4. (d) appoint accountants, legal or other professionals;
		5. **(e) maintain an updated list of claims;**
		6. (f) convene and attend all meetings of the committee of creditors;
		7. (g) prepare the information memorandum;
		8. (h) invite prospective lenders, investors, and any other persons to put forward resolution plans;
		9. (i) present all resolution plans at the meetings of the committee of creditors;
		10. (j) file application for avoidance of transactions, if any; and any such other actions


<br>

#### Can RPs be replaced? 27
- Yes; at any time during resolution process; 
- **==VOTING REQUIREMENT = 66% of voting shares==**

> ###### **❓ Is the CoC required to give any reason for replacing the RP?**
> - No  *(Case: ⚖️ **Punjab Natioanl Bank vs Kiran Shah**)*

<br>


<br>

#### Rights and Duties of authorized representative of financial creditors? - section 25A
- Such representatives -> under 
	1. **subsections 6 and 6A of Section 21**, or 
	2. **Ss5 OF s24** (meaning representative appointed by any creditor who is member of CoC to represent ihim in a meeting of the CoC)
- ! Duties?
	1. **circulate agenda and minutes** of the meeting of Committe of creds
	2. Representative shall **not act against interest of Financial creds**
	3. If FC **does not give prior instructions**, the **<u>representative shall abstain form voting on behalf of such creditor</u>**
	4. If the representative represents **multiple FCs**, then he shal **cast his vote wert each FC** in acc with **instructions received from each of them***
	5. ![[Day 1 - IBC-3.png]]



<br>

#### Set of actions that cannot be taken by resolution prof without the approaval of Committee of cred
![[Day 1 - IBC-4.png]]![[Day 1 - IBC-5.png]]

<br>


<br>

#### Resolution plan - Section 29
-  
	- ==**Infomation memorandum**== -> to be prepared by **resolution professional** 
	![[Day 1 - IBC-6.png]]

<br>


#### Persons ineligible to be resolution applicant s29A
- 
	1. person who is an **==undischarged insolvent==**
	2. person who is ==**wilful defaulted** in acc with guidelines of RBI issued under Banking regulation Act==
		- Person shall be eligible if he **makes payment of all overdue amounts eith interest** 
	3. (c) did not understand
	4. Person who has been **convicted for offence punishbable with imprisonment** 
		1. 2 yrs or more specified under 12th sched
		2. 7 years or more under any other law 
		- >This will **not apply t o a person after <u>expiry of period of 2 years from the date of his release from imprisonemnt</u>**
	5. is **disqualified to Act as director** under the Companies Act
	6.  is prohibited by the Securities and Exchange Board of India from trading in securities or accessing the securities markets;
	7. has been a **promoter or in the management or control of a corporate debtor** in which ==**a preferential transaction, undervalued transaction, extortionate credit transaction or fraudulent transaction has taken place and in respect of which an order has been made by the Adjudicating Authority under this Code;**==
		- this clause shall not apply if a preferential transaction, undervalued transaction, extortionate credit transaction or fraudulent transaction has taken place prior to the acquisition of the corporate debtor by the resolution applicant
	1. if he has **==executed a guarantee in favour o f a creditor==** in **respect of a corporate debtor** ==**against which an application for insolvency resolution made by such a creditor has been admitted under this code**== and **such guarantee has been invoked by the creditor and remains unpaid in full or in part**
	2. If he has is **subject to any disabilities** corresponding to the **earlier 8 clauses** under ==**any law in a jurisidiction outside india**==
	3. If he has a **connected person not eligible under the above 9 clauses** where a **connected person for purposes of the provision means**
		1. Any person who is the ==**promoter or in the management or control of the resolution applicant**==, or
		2.  any person who shall be the promoter or in management or control of the business of the corporate debtor during the implementation of the resolution plan
		3.  the holding company, subsidiary company, associate company or related party of a person referred to in clauses (i) and (ii):

🟥


<br>


<br>

#### Submission of Resolution Plan Section 30
- a r**esolution applicant may submit a resolution plan to the resolution professional** prepared **==on the basis of the information memorandum.==** 
	- The **resolution professional shall examine each resolution plan confirming that each resolution plan** 
		1. **provides for** the ==payment of insolvency resolution process costs in priority to the repayment of other debts of the corporate debto==r**, 
		2. **provides for the repayment of the debts of operational creditors** which shall not be less than the 
			- amount to be paid to the operational creditors in the event of a liquidation of the corporate debtor under s 53, ~~**provides for the management of the affairs of the Corporate debtor after approval of the resolution plan.**~~
            - the amount that would have been paid to such creditors if the amount to be distributed under the resolution plan had been distributed in acc with the order of prioriyy in section 53(1) whichever is higher
		1. provides for the ==**management of the affairs of the CD**== after the approval of the plan
		2. the **implementation and supervision of the plan**
		3. it <mark style="background: #FF0000A3;">does not contravene any provision of the law</mark> 
		4. it **conforms with other requriements of the board**
	- ##### After commencment of IBC Amendment act of 2019:
		- The provisions of this clause **shall aslo apply to ** the ==**CIRP of a CD**== where
			1. a resolution plan has **not been approved or rejected by the AA**
			2. wheran **appeal has been preferred under sections 61 or 62** or such appeal is not time barred
			3. where a **legal proceeding has been initiated against the decision of the AA in respect of a resolution plan**


- The r**esolution professional shall present such resolution plans to the committee of creditors for its <mark style="background: #00FF3E8C;">approval</mark> by a vote of ==not less than Sixty six percent of voting share== of the financial creditors.** 
	- The resolution applicant may attend meetings in which the resolution plan of the applicant is considered, though <mark style="background: #FF0000A3;">the applicant shall not have a right to vote unless he is a financial creditor.</mark> 

<br>

##### To whom will the resolution plan finally approved be submitted?
- To the Adjudicating Authority



<br>


#### Approval of Plan - s31
- if the Adjudicating Authority is satisfied that the resolution plan as approved by the committee of creditors meets all the given requirements, it shall by order approve the resolution plan which shall be binding on the corporate debtor and its employees, members, creditors, guarantors and other stakeholders involved in the resolution plan. 
- ==After the approval of the Adjudicating Authority, the moratorium order shall cease to have effect.==




<br>


#### Appeal from an order approving the resolution plan? - s32
- Can be filed in the **manner and on grounds laid down in section 61(3)**, meaning that it can be appealed if 
	1. plan is **in contravention of the provisions of any law**
	2. if there has been a **material irregularity in exercise of the powers fo the Professional during the CIRP**
	3. where teh **debts owed to operational creditors** of the CD have ==**not been provided for in the plan in the manner specified by the baord**==
	4. the **IRP costs have not been provided for repayment in prioroty to all other debts**
	5. the **reoslution plan** does not comply with **any other criteria specfiied by the Board**


<br>

#### Section 32A - Liability for prior offences
- Liability of a corporate debtor for an offence committed **==prior to the commencement of the CIRP==** shall ==**cease**== ;
- the **corporate debtor** shall **not be prosecuted for such an ==offence form the date the resolution the resolution plan== has been approved by th AA under [[#Approval of Plan - s31|Section 31]]** 
##### To whom does the immunity under the Section extend?
1. person who **==were NOT promoters or part of th manaagement of the CD or the related parties that are made i charge of management in placce of the coroprate debtor by the resolution plan==**
2. to such persons that **==were not found to be abetting or conspiring the commission of an offence by the relevant adjudicating authority==** based on material evidence in its possession
##### To whom shall the immunity not extend 🔴
1. to persons who ==**were involved in the commission of the offence or were associated with the corporate debtor in this regard**==
2. The proviso to these conditions states that any prosecution instituted against the corporate debtor during the CIRP will be discharged if the corporate debtors fulfil the above-mentioned conditions. The second proviso to the sub-section further adds that **any person who can be classified as a designated partner as per the definition of [Section 2(j)](https://indiankanoon.org/doc/192591716/) of the [Limited Liability Partnership Act 2008](https://legislative.gov.in/sites/default/files/The%20Limited%20Liability%20Partnership%20Act,%202008.pdf), or any officer who was in default as per the definition of [Section 2(60)](https://www.indiacode.nic.in/show-data?actid=AC_CEN_22_29_00008_201318_1517807327856&sectionId=185&sectionno=2&orderno=2) of the [Companies Act 2013](https://www.mca.gov.in/Ministry/pdf/CompaniesAct2013.pdf), was indirectly or directly involved in the commission of the offence or was responsible or in-charge of the business affairs of the corporate debtor or was in any way associated to the corporate debtor in any wa**y ==**shall not be exempted from any liability and will be prosecuted for the offence committed by the corporate debtor and shall be punished accordingly.**==

##### Is  any person claiming the benefit under the previous sub-sections is not free from providing required assistance to the investigating and is obligated to provide assistance to any investigating authority investigating under any applicable law?
- Sub-section 3 of the abovementioned Section adds that, with reference to the immunity given under sub-sections 1 and 2, states that any person claiming the benefit under the previous sub-sections <mark style="background: #FF5582A6;">is not free from providing required assistance to the investigating and is obligated to provide assistance to any investigating authority investigating under any applicable law.</mark> 

<br>


---


### Chapter 3:  LIQUIDATION PROCESS CH III - (33-54)

>[[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan#Liquidation|From TK Vishwanathan report]]

[[Liquidation Process 1.png]]
![[Liquidation Process 1.png]]

#### Inititation of Liquidation
1. According to this section if the Adjudicating Authority:
	- (a) ==before the expiry of the **[[#Insolvency resolution Process period 14]]**== or the maximum period permitted for completion of the corporate insolvency resolution process or the fast track corporate insolvency resolution process, as the case may be, ==**does not receive a resolution plan**==; or
	- (b) ==**rejects the resolution plan for the non-compliance of the requirement**==s, it shall - ^4936ef
		1. (i) pass an order r**equiring the corporate debtor to be liquidated in the laid down manner;**
		2. (ii) issue a p**ublic announcement** stating that the corporate debtor is in liquidation; and
		3. (iii) r**equire such order to be sent to the authority with which the corporate debtor is registered.**

2. If at ==**any time during the corporate insolvency resolution process**== **<mark style="background: #FF4E00A6;">but before confirmation of resolution plan</mark> **, the resolution professional ==**<u>intimates the Adjudicating Authority of the decision of the committee of creditors to liquidate the corporate debtor, the Adjudicating Authority shall pass a liquidation order.</u>**==

1. Where RP is **contravened by the corporate debor**, then **any person ==other than corporate debtor== whose ==interests are prejudicially affected by such contravention==** -> may **make an ==appl.ication to AA==** for liquidaton order as given under (b) -> [[#^4936ef|see here]]
	- On receipt of this application, if AA **determines that CD has contravened the provisions of the Resolution plan**, then it <mark style="background: #00FF3E8C;">pass order to liquidate as given under [[#^4936ef|section 33(b)]]</mark> 

##### Can suit be instituted against corporate debtor onece liquidation order has been passed
- Subject to section 52
- Generally no
- SUit **may be institited by the liquidator on behalf of th ecorporate debtor** with the **prior approval of the adjudicating authority**

<br>

<br>


#### Appointment of Liquidator and fee 34
##### Who is liquidator otherwise?
- After the Adjudicating Authority passes an order for liquidation the ==**appointed resolution professional shall act as the liquidator unless replaced**==, provided that his ==**consent has been given to the AA in specified form**==. All powers of the board of directors, key managerial personnel and the partners of the corporate debtor shall vest in the liquidator.
##### Can he be replaced?
- Adjudicating Authority shall replace the resolution professional, if:
	1. (a) the <mark style="background: #FF0000A3;">resolution plan submitted by the resolution professional was rejected for failure to meet the mentioned requirements</mark> , in **<u>this case</u>** the ==**Adjudicating Authority may direct the Board to propose the name of another insolvency professional to be appointed as a liquidator**==, the Board in such case shall propose a name within 10 days; or
	2. (b) the ==**Board recommends such replacement to the Adjudicating Authority**== for reasons to be recorded in writing, in this case the Authority shall appoint the proposed insolvency professional as liquidator.
	3. The resolutio professional **fails to submit written consent under subsection 1**

> ##### Can the CoC move an application for removal of liquidator?
> - No, once the order of liquidation is passed, ther are **mere claimants whose matters are to be determined by the liquidator**; they thus <mark style="background: #FF0000A3;">**cannot move an application for removal of the liquidator**</mark> 
> 
> Case:***⚖️ Punjab National Bank vs Mr Kiran Shah (NCLAT)***
<br>


<br>

#### Powers and duties of liquidator 35
1. (a) to **==verify claims of all the creditors==;**

2. (b) to **==take into his custody or control all the assets, property, effects and actionable claims of the corporate debtor;==**

3. (c) to **==evaluate the assets and property of the corporate debtor by the Board and prepare a report;==**

4. (d) to take ==**such measures to protect and preserve the assets and properties of the corporate debtor as he considers necessary;**==

5. (e) to **==carry on the business of the corporate debtor for its beneficial liquidation as he considers necessary;==**

6. (f) to **==sell the immovable and movable property and actionable claims of the corporate debtor in liquidation by public auction or private contract;==**

7. (g) to draw, accept, make and endorse any negotiable instruments including bill of exchange, hundi or promissory note in the name and on behalf of the corporate debtor;

8. (h) to take out, in his official name, letter of administration to any deceased contributory and to do in his official name any other act necessary for obtaining payment of any money due and payable from a contributory or his estate which cannot be ordinarily done in the name of the corporate debtor, and in all such cases, the money due and payable shall, for the purpose of enabling the liquidator to take out the letter of administration or recover the money, be deemed to be due to the liquidator himself;

9. (i) to **obtain any professional assistance from any person or appoint any professional, in discharge of his duties, obligations and responsibilities;**

10. (j) to **==invite and settle claims of creditors and claimants and distribute proceeds in accordance with the provisions of this Code;==**

11. (k) to institute or defend any suit, prosecution or other legal proceedings, civil or criminal, in the name of on behalf of the corporate debtor;

12. (l) to investigate the financial affairs of the corporate debtor to determine undervalued or preferential transactions;

13. (m) to take all such actions, steps, or to sign, execute and verify any paper, deed, receipt document, application, petition, affidavit, bond or instrument and for such purpose to use the common seal, if any, as may be necessary for liquidation, distribution of assets and in discharge of his duties and obligations and functions as liquidator;

14. (n) to ==**apply to the Adjudicating Authority for such orders or directions as may be necessary for the liquidation of the corporate debtor and to report the progress of the liquidation process in a manner as may be specified by the Board; and**==

15. (o) to perform such **==other functions as may be specified by the Board.==**

<br>

<br>


#### What is Liquidation Estate? section 36
- It is estate formed for the **liquidation**; the ==liquidator shall **form an estate of the assets**==; he will **hold them as a fiduciary for the benefit of creditors**
- It shall cojmprise of all liquidation assets including
	1. (a) Any assets over which the corporate debtor has ownership rights;
	2. (b) assets that may or may not be in possession of the corporate debtor including but not limited to encumbered assets;
	3. (c) tangible assets, whether movable or immovable;
	4. (d) intangible assets including but not limited to intellectual property, securities, financial instruments, insurance policies and contractual rights;
	5. (e) assets subject to the determination of ownership by the court or authority;
	6. (f) any assets or their value recovered through proceedings for avoidance of transactions;
	7. (g) any asset of the corporate debtor in respect of which a secured creditor has relinquished security interest; and
	8. (i) all proceeds of liquidation as and when they are realised.

##### What cannot be included in liquidation assets?
1. **(a) assets<mark style="background: #FF5582A6;"> in possession of the corporate debtor but has no ownership rights</mark> over it.**
2. (b) assets in security collateral held by financial services providers and are subject to netting and set-off in multi-lateral trading or clearing transactions;
3. (c) <mark style="background: #FF5582A6;">**personal assets of any shareholder or partner of a corporate debto**r;</mark> 
4. (d) assets of any Indian or foreign subsidiary of the corporate debtor; or
5. (e) any other assets as may be specified by the Board, including assets which could be subject to set-off on account of mutual dealings between the corporate debtor and any creditor.
> - Dues to **workmen or employees**, inother words *provident fund, pension fund, and gratuity fund* **==do not form part of the lliquidation estate==** 
> 
> Case: ***⚖️ State Bank of India vs Moser Baer Karamchari Union and Others***

<br>


<br>

#### Powers of Liquidator to access information
- Why? -> for **admissio and proof of claims** and **identification fo the liquidation estate assets relating to the coprorate debtor**
- sources: 
	1. (a) an [[#Information Utility]];
	2. (b) credit information systems regulated under any law for the time being in force;
	3. (c) any agency of the Central, State or Local Government including any registration authorities;
	4. (d) information systems for financial and non-financial liabilities regulated under any law for the time being in force;
	5. (e) information systems for securities and assets posted as security interest regulated under any law for the time being in force;
	6. (f) any database maintained by the Board; and
	7. (g) any other source as may be specified by the Board.

The liquidator shall provide information to such creditors who have requested for any financial information within a period of seven days.

<br>


<br>

#### Consolidation of claims - s38
##### Duration for collection and recieving of claims of creditors?
- within ==**30 days**== from the **==commencment of the liquidation process==**
	1. A **<u>financial creditor may submit a claim to the liquidator by providing a record of such claim with an information utility.</u>** 
	2. An o**<u>perational creditor may submit a claim to the liquidator in a form and manner and along with supporting documents to prove the claim.</u>** 
	3. A **<u>creditor who is partly a financial creditor and partly an operational creditor shall submit claims to the liquidator to the extent of his financial debt and his operational debt.</u>** 
- A creditor ==**may withdraw or vary his claim**== within<mark style="background: #00FF3E8C;"> fourteen days of its submission.</mark> 


<br>

#### Verification of claims - s39
- Liquidator should ==**verify the claims**== w/in a specified time
- The liquidator may also **require any creditor or the corporate debtor or any other person to produce any other document or evidence which he thinks necessary for verification.**

<br>


<br>

#### Admission or rejection of claims - s 40
- Liquidator may either **admit or reject the claim** and **communicate the same in writing** to the **==creditor and the corporate debtor==** w/in ==**seven days**==
	- rejection -> **reasons to be recorded in writing** 
#### Valuation of Claims s41
- He ==shall **determine value of claims**==

#### Appeal 🔴 s42
- Creditor <mark style="background: #00FF3E8C;">**can appeal to AA**</mark>  against the **<u>decision of the liquidator to reject a claim</u>**


<br>


<br>

#### Preferential Transactions and relevant time - s43
> - one of the objectives of the CIRP is the ==**maximization of assets of the corporate debtor,**== 
> 	- therefore, the CIRP process **must avoid any such circumstance which diminishes the valuation of the corporate debtor.** 
> - The entire concept of the moratorium which puts on hold all other recovery proceedings going against the corporate debtor, in itself centres around the idea that the valuation of the corporate debtor should not diminish during the CIRP. 
> - Based on the exact principle that is to maximize the value of assets available to the creditors, ==**the Code places similar provisions to ensure that there are no such unnecessary or fraudulent transactions, having taken place prior to the CIRP that can in any capacity diminish the value of the corporate debtor.**==
- According to this section, when the liquidator or the resolution professional is **==of the opinion that the corporate debtor has at a relevant time==** ==**given a preference in transactions to any persons**==, he <mark style="background: #FF0000A3;">shall apply to the Adjudicating Authority for avoidance of preferential transactions.</mark> 
- A preference **<u>shall not include the following transfers:</u>**
	- (a) **transfer made in the ordinary course of the business or financial affairs of the corporate debtor or the transferee;**
	- (b) any transfer creating a security interest in property acquired by the corporate debtor to the extent that:
		1. (i) such security interest secures new value and was given at the time of or after the signing of a security agreement that contains a description of such property as security interest and was used by corporate debtor to acquire such property; and
		2. (ii) such transfer was registered with an information utility on or before thirty days after the corporate debtor receives possession of such property:

- **==A preference shall be deemed to be given at a relevant time, if:==**
	1. (a) it is given to a related party (other than by reason only of being an employee), during the period of two years preceding the insolvency commencement date; or
	2. (b) a preference is given to a person other than a related party during the period of one year preceding the insolvency commencement date.

> - The concept of preference is essentially premised on 
> 	1. fairness and 
> 	2. equity: 
> - when a company is on the brink of insolvency, <mark style="background: #FF4E00A6;">paying off one creditor may be detrimental to the interests of the other creditors as it would result in a diminution of total assets available for distribution to other creditors.</mark> 
> - The operation of section 43 is to deter what is called ‘_the race of diligence_’ of creditors to dismember the corporate debtor before insolvency. 
> - The ==**prohibition of preferential transactions also furthers another goal – that of equality of distribution.**== Thus, if a corporate debtor has made preferential payments to unrelated creditors within a period of one year preceding the insolvency commencement date, the resolution professional/liquidator, after his or her appointment, can challenge transfers that have conferred particular creditors of the corporate debtor a material advantage relative to its other creditors.

<br>

#### Avoidance of undervalued transactions -45
>**Object**: to **prevent siphoning off of assets** by the personnel of the CD when **in the vicinity of insolvency**
- This section provides that i**f the liquidator or the resolution professiona**l, on **examination of the transactions of the corporate debtor** determines that ==**certain transactions were undervalued,**== he **==<u>shall make an application to the Adjudicating Authority to declare such transactions as void and reverse the effect of such transactions</u>==**. 
- A transaction shall be considered undervalued where  #important 
	1. the corporate debtor makes a gift to a person or 
	2. enters into a transaction with a person which involves the transfer of one or more assets by the corporate debtor in a significantly lesser value than the actual consideration value and such transaction has not taken place in the ordinary course of business.
##### Relevant period for avoidable transactions at undervalue s46
- <mark style="background: #00FFFE73;">**Section 46**</mark>  in **application for avoiding a transaction at undervalue** -> liquidator or resolution professional ==shall demonstrate== that
	1. transaction -> case of ==**any person**== -> made **==once yeare preceding the insolvency commencement date==** 
	2. when transaction made with a <mark style="background: #00FF3E8C;">**related party**</mark>   wi/in <mark style="background: #FF4E00A6;">**2 years preceding insolvency commencement date**</mark> 

##### APplication by creditor where liquidator has not reported the undervalued transaction to the adjudicating authority? - s47
- Can approach AA to **<u>declare the transaactions void and reverse thier effect</u>**
##### Order in cases of undervalued transactions - s48
![[Day 1 - IBC-7.png]]

<br>

##### Where undervalued transactions under s45(2) are not reported to AA by Liquidator - Section 47
- The creditor/member/parnter of a corporate debtor may ==**make an application to the AA**== to ==**declare such transactions void and reverse thier effect in acc w/ this chapter**== #important 
###### What shall the court do next?
- If the court is satisfed that **a) undervalued transactions had occurred** and **b) liquidator or the resolution professional after <u>having sufficient information or opporutnity to get such information of such transactions did not report such transaction to AA</u>** ... -> it ==**shall pass an order**==
	1. **restoring** the position as it exissted **before such transacntions** and **==reversing the effects thereof==** in the manner laid down in s48 and 45
	2. requireing the baord to **initiate disciplinary proceedings against the liquidatotr** or **RP** 


<br>

#### Transactions defrauding creditors - s49
- 
	- Where undervalued transaction in s45(2) was entered into by Corp Debtor; and if the **court is satisfied that such ==transaction was deliberately entered into by the CD==** for 
		1. **keeping assets of the corporate debtor beyond the reach of any person who is entitled to make a claim against the corporate debto**r; or
		2. i**n order to adversely affect the interests of such a person in relation to the claim**,...
	- ...Then the **==AA==** shall make an order
		1. **resotring the position as it existed before such trnasaction** <mark style="background: #FF4E00A6;">as through the **transaction had not been entered into**</mark> 
		2. **protecting** the ==**interests**== of **<u>persons who are victims of such transactions</u>**

##### What if the person who acquired the property did so in good faith fo value and w/out notice fo the relevant circumstances?
- Then the order **<u>shall not affect the interest in property of such party or any interest deriving from such interest</u>**
##### What about parties who acquired benefit formthe transaction in good faith for value and w/o notice of relevant circumstances?
- Such party **shall not be required to pay any sum** unless he was **<u>party to the transaction</u>** 🟥

<br>

<br>


#### Extoritionate credit transactions - s50 
> extortionate credit transactions as those transactions entered into by the corporate debtor requiring exorbitant payment to be made by the corporate debtor in receipt of financial or operational debt during the period within two years from the insolvency commencement date.


where the corporate debtor **has been a party to an extortionate credit transaction involving the receipt of financial or operational debt during the period within two years preceding the insolvency commencement date**, the ==**liquidator or the resolution professional may make an application for avoidance of such transaction to the Adjudicating Authority if the terms of such transaction required exorbitant payments to be made by the corporate debtor.**==
##### What is credit?
- Credit means a ==**loan or any other form of financial accomodation**==
	- these include *loans, hire-purchase, or deferred payments*

##### When shall the transaction be deemed to be extortionate?
1. When it requires the **corporate debtor** to ==**make exorbitant payments**== in respect of the credit provided or 
2. where the terms of the transaction are <mark style="background: #FF0000A3;">**unconscionable under terms of contract law**</mark> 

###### When can a transaction be deemed to be unconscionable under Law of Contracts?
1. where agreement is signed by the borrowere **without having proprer opportunity to read the terms and conditions**
2. Where an agreement is entered into in **threatening or intimidating circumstances**
3. agreemenentered into at a **time or in circumstances where the borrower was vulnerable**
4. where the **borrower** was **induced to enter into the agreement by false or misleading statements**
5. where the **important details are hidden in small print**
6. where ==**interest is charged**== on **monies not lent** 
##### Section 51 - Orders of AA wrt such transactions
- where the Adjudicating Authority after examining the application is **satisfied** that the **terms of a credit transaction required exorbitant payments to be made by the corporate debto**r, it shall 
	1. restore the position as it existed prior to such transaction, 
	2. set aside the debt created on account of the extortionate credit transaction, 
	3. modify the terms of the transaction, 
	4. require any person who is, or was, a party to the transaction to repay any amount received by such person or 
	5. require any security interest that was created as part of the extortionate credit transaction to be relinquished in favour of the liquidator or the resolution professional.

<br>


<br>

#### Secured creditor in liquidation proceedings can relinquish security interest to the liquidation estate - s52
```ad-summary
- This section provides that a [[#Secured creditor 3 30|secured creditor]] may 
	1. choose to **relnquish its interest** and **participate in the distribution of assets**, or
	2. **realise itse security ==outside the liquidation proceedings==**


```

- secured creditor in the liquidation proceedings **==may relinquish its security interest to the liquidation estate and receive proceeds from the sale of assets by the liquidator or realise its security interest==**, 
- however **==he shall inform the liquidator of such security interest and identify the asset to be realised==**. 
- Before any security interest is realised by the secured creditor, the ==**liquidator shall verify such security interest**==. 
- <mark style="background: #FF4E00A6;">The secured creditor shall be permitted to realise only when the existence of such security shall be proved either by the records maintained by an information utility or by such other specified means.</mark> 
##### Can the secured creditor realise his security during the moratorium period? 
- No 
	- the secured creditor **cannot take nay coercive action on the security interest of the CD** ***during the CIRP***



<br>


<br>

#### DIstribution of Assets - s 53
![[📘 Section 53 of the IBC|📘 Section 53 of the IBC - Distribution of assets.]]

---
#### Dissolution of CD - Section 54
- after the complete liquidation of the assets of the corporate debtor, the ==**liquidator shall make an application to the Adjudicating Authority for the dissolution of the same.**== 
- Where after the Adjudicating Authority shall on the filed application filed by the liquidator order that the corporate debtor shall be dissolved accordingly.

----

### Chapter 3-A: PREPACKAGED IRP (54A - 54P)

> **To be read with [[The Insolvency and Bankruptcy (pre-packaged insolvency resolution process) Rules, 2021]]**

![[pre-packaged insolvency resolution process]]
> BAP means best alternative plan ![[Day 1  IBC-1.png]]

#### Who can initiate applicate for PPIRP? - 54A
- it can be **made ==in respect of==** [[#Who is a corporate debtor s3 8|corporate debtor]] **classfied as ==Micro, Small, or Medium enterprise==** under s7 of MSME Development act 2006
- The creditor and corporate debtor **cannot be related parties**

<br>


##### What are the requirements that the corporate debtor must satisfy?
1. It has **notundergone PPIRP** or **completed CIRP** before the period of ==**3 years preceding the initiation date**==
2. it  is **==not undergoing a CIRP==**
3. no **<u>order  requiringit to be liquidated</u>** has been passed under **[[#LIQUIDATION PROCESS CH III - 33-54|Section 33]]**
4. It is **eligible  to submit a  resolution plan** under [[#Persons ineligible to be resolution applicant s29A|Section 29A]]
5. The financial creditors of the CD **not being related parties** have **==proposed the name of the Insolvency Professional==** who is to be appointed as [[#Resolution professional]] for conucting the insolvency process
6. The majority of the directors or parnters of CD -> made  declaration stating that  ^38ff04
	1. Cd shall **file an application for initiating PPIRP** within a **definite time period not exceeding 90 days**
	2. PPIP is **not initiated to defraud any person**
	3. the ==**ame of IP proposedand approved**== who is to be **appointed as RP
7. Members of the CD -> passed <mark style="background: #00FF3E8C;">**special resolution** </mark> or at least **three fourth of partners** of the C hav epassed a resolution -> ==**approving of the filing of an application for initating PPIRP**== ^8f7714

<br>


##### How many creditors should agree to the proposal for PPIRP
- Financial creditors ofthe CD **not being its [[#Related party|related parties ]]** ==representing **atleast 66% of the financial debt**== ddue to such creditors
##### What if a corporate debtor does not  have any financial creditors not being his related parties?
- The proprosal and approval **shall be provided by such persons as may be specified**

<br>


##### Creditor requirement for approval?
- Approval from **financial creditor** who are
	1. not his [[#Related party]] adn 
	2. represnting at least ==**66% of fin inancial debt**==



<br>

##### What should CD submit in order to seek approval of FCs for PPIRP - subsection 4
- [[#^38ff04|Declaration referred to in clause of of subsection 2 of section 54A]]
- [[#^8f7714|special resolution plan referred to in clause g of subsection 2]]
- a [[#Base Resolution plan 5 2A|Base reslution plan]] which **conforms to requirement in section 54K**
- any other info and docs specified

<br>

#### Duteis of professional - s54B
- prepare report confirming requirements under [[#Who can initiate applicate for PPIRP - 54A|Section 54A]] and the base resolution plan **conforms with requirements given in [[#What should CD submit in order to seek approval of FCs for PPIRP - subsection 4|subsection 4 of 54A]]]]**
- file such reports ==**with the board**==
- perform **other such duties** as specified

##### When will the duties cease?
1. where CD **fails to file an application for initiating PPIRP88 within the **time period as stated in the declaration** reffered in [[#^38ff04|clause f of section 54A(2)]] or
2. the **application for initating PPIRP** is **admitted or rejected by the authority**


<br>

#### Application to initiate PPIRP
1. WHere CD => **meets requirement of section 54A** -> CD may **==file an application with the AA for  initiating PPIRP**==
	- this application shall be **filed in manner and form prescribed along with fee**
##### What would the applicant have to furnish
1. [[#^38ff04|declaration]], [[#^8f7714|special resolution]], or resolution as the case may be, and the ==**approval of the financial creditrs for initing PPRIP**==
2. **name and written consent** of the insolvency professionals proposed to be appointed as RP
3. declaration -> regarding of avoidance of transactions under CHIII or **fraudulent or wrongful trading under Chapter VI**
##### Duration for AA to decide application
- 14 days
- AA can either **admit or reject** if it is incomplete; AA ==can give **notice to the applicant** to **rectify the defect in the application** within **7 days form the date fo receipt fo such notice**== from the AA

<br>


#### When does PPIRP  commence?
- From the ==**date of admission of the application**== byt eh AA #important 

##### Time period for completion of the process? - 54D
- Within ==**180 days from PPIRP**== commencement date

###### Time period for RP to submit the resolution professional to submit the Resolution plan as approved by the committee of creditors to the AA under subsection 4 and susection 12 of section 54K
- **==90 DAYS==**

##### What if NO RESOLUTION PLAN IS APPROVED BY THE COC within the TIME PERIOD of 90 days? - 54D
- **Resolution professional** -> on the ==**date after the expiry of such time period**== -> **file an application with the AA** for the ==**termination of the PPIRP**== 


<br>

#### Moratorium - section 54E
- To be declared by the Adjudicating authority **along with the order of admission**
- [[#When does moratorium end|Moratorium as declared in ss3 of Section 14]] ->applies mutatis mutandis
- AA will appoint **resolution professional**
	1. as **named in the application** if **no disciplinary proceeding is pending** against him, or
- ==**Public announcement of initiation of PPIRP will be made by the RP**==
##### Moratorium to extend until?
- Until the **date on which the PPIRP comes to an end**

<br>

#### Duties of Resolution professional - Section 54F
- (a) confirm the list of claims submitted by the corporate debtor under section 54G, in such manner as may be specified;
- (b) inform creditors regarding their claims as confirmed under clause (a), in such manner as may be specified;
- (c) maintain an updated list of claims, in such manner as may be specified;
- (d) monitor management of the affairs of the corporate debtor;
- (e) inform the committee of creditors in the event of breach of any of the obligations of the Board of Directors or partners, as the case may be, of the corporate debtor, under the provisions of this Chapter and the rules and regulations made thereunder;
- (f) constitute the committee of creditors and convene and attend all its meetings;
- (g) prepare the information memorandum on the basis of the preliminary information memorandum submitted under section 54G and any other relevant information, in such form and manner as may be specified;
- (h) file applications for avoidance of transactions under Chapter III or fraudulent or wrongful trading under Chapter VI, if any; and 
- (i) such other duties as may be specified.
#### Powers of Resolution professional - Section 54F
- (a) access all books of account, records and information available with the corporate debtor;
- (b) access the electronic records of the corporate debtor from an information utility having financial information of the corporate debtor;
- (c) access the books of account, records and other relevant documents of the corporate debtor available with Government authorities, statutory auditors, accountants and such other persons as may be specified;
- (d) attend meetings of members, Board of Directors and committee of directors, or partners, as the case may be, of the corporate debtor; 
- (e) appoint accountants, legal or other professionals in such manner as may be specified;
- (f) collect all information relating to the assets, finances and operations of the corporate debtor for determining the financial position of the corporate debtor and the existence of any transactions that may be within the scope of provisions relating to avoidance of transactions under Chapter III or fraudulent or wrongful trading under Chapter VI, including information relating to —
- (i) business operations for the previous two years from the date of pre-packaged insolvency commencement date;
- (ii) financial and operational payments for the previous two years from the date of pre-packaged insolvency commencement date;
- (iii) list of assets and liabilities as on the initiation date; and
- (iv) such other matters as may be specified;
- (g) take such other actions in such manner as may be specified.
#### Duties towards RP?
- Financial instituions maintaining accounts fo the CD -> to **furnish all info r/lating to the CD with them to RP** when required by him
- Personnel of CD and persons associated with its management -> **extend all assistance and cooperation to teh RP** as and when requiredby him to perform his duties

<br>

#### List of claims - 54G
- CD w/in 2 days of commencement date -> **==CD to submit to the resolution professional==**
	1. a **list of claims** along with **details of the the respective creditors**, their security interests, and guarantees if any
	2. a **preliminary information memorandum** that ==contains **relevant information** in order to **formulate a resolution plan**==

##### Where any person has sustained loss/dmage as consequence of omission of material information in the list of claims or preliminary information memorandum submitted by CD?
- Every person who is a **promoter or director or partner of the CD**  at the **time of the submission of the list of claims**/information memorandum, or a **person** who has **authorised the submission of the list of claims/prelim information memorandum** by the CD shall ---> ==without prejudice to [[#Punishment - offence r ating to PPIRP - s77A|Section 77A]]== shall be **==liable to pay compensation to every person who has sustained such loss or damage==**

<br>


#### Managment of affairs of corporate debtor
- During **pre-packaged IRP**, the management contrastingly <mark style="background: #00FF3E8C;">**stays with the Bod or the partners fo the corp debteor**</mark> 
	- BOD /partners of the CD -> to make every endeavour to **Protect and preserve the value of the proeprty of the CD**
##### Can the management be vested with the resolution professional - 54J
- Yes; where the **COC** -> at any time **during the PPIRP process period** -> by ==**vote of at least 66%**== of the voting shares -> decide to **vest management of CD with RP**

###### When can AA affirm the application
1. when the **affairs of CD** have been **conducted in a fraudulent manner**
2. wher -> **gross mismanagement of affairs fo CD**


<br>

#### Committee of Creditors - 54-I
##### When to be constituted?
- Within **seven days of PPIRP commencement date** on the basis of the info **provided by the CD under section 54F(2)**
##### Can new members be added on the basis of updated list of claims?
- Yes
###### Will this affect the validity of any past decision of the CoC?
- Nope

<br>

#### Consideration and approval of the Resolution Plan - 54K
1. CD will **submit base resolution plan** to teh RP w/in 2 days of commencment date
	- COC may **provide CoC an opportunity to revise the Base resolution plan** prior to its approval
1. Base reslution plan to conform to [[#Submission of Resolution Plan Section 30|Section 30]]
- COC -> may affirm the plan where it ==**does not impair any claims owed by the CD to the operational creditors**== #important 
##### What if CoC does not approve 🔴 the Base resolution plan, or if the plan impairs any of the claims owed by the CD to the operational creditors?
- Resolution professional -> will ==**will invite prospective resolution applicants to submit a resoution plan/plans to compete with the base resolution plan**==
##### Wht happens if the CoC decides that on the basis of criterion laid down by it , the Plan submitted by the resolution applicant is significantly better than the base resoution plan?
- Such plan may then be ==**submitted for approval**==
###### What if the above plan is NOT considered for approval, or is not deemed to be significantly better thean BRP by the CoC?
- Then it will **copmete with the base resolution plan**
>If this plan is not approved by the committee of creditors, then the <mark style="background: #FF0000A3;">**RESOLUTION PROFESSIONAL WILL FILE AN APPLICATION FOR TERMINATION OF PPIRP PROCESS**</mark> 

##### Required vote by the CoC for approval of plan?
- 66% of total voting shares



<br>

#### Approval of Plan by AA - Section 54L
- If AA is satisfied that plan approved by e CoC -> meets requirements contained in [[#Submission of Resolution Plan Section 30|Section 30(2)]] 
##### Time limit for approval of plan by AA?
- Within ==**30 days**== of the receipt of the plan

##### Can this Order approving the Resolution plan be challenged? - Section 54M
- Yes it can be on the grounds laid down in **<mark style="background: #00FFFE73;">Section 61</mark>** -> meaning that it can be appealed if 
	1. plan is **in contravention of the provisions of any law**
	2. if there has been a **material irregularity in exercise of the powers fo the Professional during the CIRP**
	3. where teh **debts owed to operational creditors** of the CD have ==**not been provided for in the plan in the manner specified by the baord**==
	4. the **IRP costs have not been provided for repayment in prioroty to all other debts**
	5. the **reoslution plan** does not comply with **any other criteria specfiied by the Board**

##### What if AA satisfied tha the plan DOES NOT CONFORM TO THE REQUIREMENTS of section 30(2)?
- It will **order the ==rejection fo the plan under Section 54(N)==**
#### What if CoC decides to vest control of CD in the RP and AA passes an order to that effect, but this order is not complied with and there is no change in the managment ro control fo the CD to a person who was not a promoter of the same or in control of the CD
1. AA will pass ==**order to reject the Resolution plan**==
2. will ==**terminate the PPIRP**== and will **<mark style="background: #FF4E00A6;">pass an liquidation order in respect fo the CD</mark>** 🔴
3. will **declare** that the PPIRP costs if any -> to be **included as part of the liquidation costs** for the purposes of **liquidation of the Corporate debtor**


<br>

#### Can the CoC at any time after PPIRP comencement date but prior to approval -> resolve to initiate CIRP against the CD?
- Yes, if CD is ==**eligible for CIRP under Ch 2**==
##### Time limit for passing order by AA
- WIthin ==**30 days**== of the **==date of intimation==** by the ==**resolution professional**==
- AA will ==**terminate the PPIRP**== and <mark style="background: #00FF3E8C;">Initiate CIRP under Chapter II</mark> 

##### Who will be Resolution professional for the CIRP?
- The RP under **section 54E** provided that he **consents**

###### What if he fails to submit written consent?
- AA will appoint an ==**interim resolution professional**== by **making reference to the Baord for recommendation** in manner provided under [[#Appointement of Interim RP s16|Section 16]]
##### Effect of Order of A for termination of PPIRP and initiation of CIRP?
- Order -< deemed to be an ==**ordr of admission of an application**== under section 7 of the code
- CIRP to ==**commence from the date fo the order**==
- in **coputing relevant time period for ==avoidable transactions==** -> <mark style="background: #FF0000A3;">the **time period** of the duration of the **PPIRP** shall **also be included**</mark> 

---
### Chapter 4: FAST TRACK CIRP (55-58)
#### When can FTCIRP be carried out?
1. When a **corporate debtor** with ==**assets and income** below a **level as notified by the central governement**==
2. a CD with ==**such class of creditors or such amount of debt**== as may be notified by the Central government
3. or such other category of corporate persons as may be notified by the Central govt

#### Duration for completion
- Period of ==**90 days from insolvency commencement date**==
##### Can the period be extended?
- Yes upon **RP** filing an **application ot the AA** to extend the period
	- the vote of ==**75% of the voting share of CoC**== is required
- Duration -> extendable up to ==**45 days**==

<br>

#### Manner of initiation FTCIRP
- Application to be accompanies by
	1. **proof** of the **existence of default** <- evidenced by **records available** with an [[information utility (IBC)]] or such other means as specified by the board
	2. and such **other info** as may be **specified by the Board** to establish the CIRP




---
### Chapter 5: VOLUNTARY LIQUIDATION S59

![[Diagram 1.svg]]


#### Who can initiate voluntary liquidation?
- A corporate person who
	1. **intends** to liquidate itself voluntarily
	2. has **not committed any default**


<br>

#### Conditions required to be met by the company
1. **Majority of directors** of the company must **make a ==declaration== via an ==affidavit==**  stating that 
	1. either the **company has no debt**, or the company will be able to pay its debts in full from the proceeds of assets to be sold in the voluntary liquidation
	2. the company is <mark style="background: #FF5582A6;">**not being liquidated to defraud any person**</mark> 
2. The declaration must be accompanies by
	1. **audit financial statements and record of business operations** of the company for previous 2 years or for the **period since its incorporation** (whichever is later)
	2. report of ==**valuation of assets of company**== prepared by a registered valuer
3. Within 4 week sof the declaration, there shall be a
	- ==**special resolution**== of the **==members of the company==** in a **general meeting** -> requiring the company to be 
		1. ==**liquidated voluntarily**==
		2. and **appointing** and [[#Resolution professional|insolvency resolution professional]] to act as a [[#Liquidator 18|liquidator]]
	
	**OR**
	- a resolution of **members** of the copmany in a **general meeting** -> requiring the company to be **lqiuidated voluntaryily** as a **result of the ==period of its duration if any that is fixed by its articles==** such that on the ==**occurrence of any event (as provided in the articles), the company shall be dissolved**==

1. The ==**creditors  representing two-thireds in value of the debt of the copany**== shall <mark style="background: #00FF3E8C;">approve the resolution passed by the members of the company</mark> 

<br>


#### Further procedure
1. Company will **notify the ==Registrar of Companies==** as well as the ==**Board**== about the resolution to liquidate the company **within 7 days of such resolution**
2. Provisions of [[#Powers and duties of liquidator 35|Section 35]] to [[#DIstribution of Assets - s 53|Section 53]]  of shall apply to voluntary liquidation proceedings
3. After the **affairs of the Corporate person** have been **completely wound up** -> the liquidator shall ==**make an application to the AA**== for the **dissolution of such corporate persons** -> AA will on such application ==**pass an order that the CD shall be dissolved from the date of the order**==


---
### Chapter 6: ADJUDICATING AUTHORITY FOR CORP PERSONS (60-67A)

#### Adjudicating authority for corporate persons
- To be the NCLT

#### Appeals
- person aggrieved by the order of AA -> file appeal to **==national company law appellate tribunal==**
- every appeal -> w/in 30 days
##### Can appeal be allowed after period of 30 days?
- Yes upon being satisfied that ==**there was sufficient cause for not filing the appeal **==
- extra 15 days

##### Grounds for appeal?
- approved Resolution plan -> in contravention of law in force
- **material irregularity** in exercise of the **powers by the resolution professional** during the **IRP**
- debts owed to [[#Operational creditor 20]]s of CD ahve ==**not been provided for in the Resolution plan in the manner specified by the board**==
- insolvency process resolution costs have **not been provided for repayment in priority to all other debts**, or
- Rsoution plan does not comply with **other criteria specified by the board**
- <mark style="background: #FF4E00A6;">Appeal against Liquidation order passed under Section 33 or section 54(L)(4) or section 54N(4) </mark> or **fraud committed in relation to such order**

<br>

#### Appeal to Supreme Court
- When perso aggrieved by order passed by NCLAT
	- on **==question of law arising out of such order==**


<br>

#### Jurisdiction of Civil court is Barred

<br>

#### Whereapplication not disposed of within period specifed in this code?
- NCLT or NCLAT -> shall ==**record reasons in writing for not doing so**== -> and the ==**PRESIDENT OF THE NCLT**== or the ==**chairperson fo the NCLT**==  -> after taking into account the rasons may ==**extend the period specified by maximum 10 days**==

<br>

#### Fraudulent/malicious initiation of liquidation or IRP or purpose other than for reoslution or insolvency
- AA to **impose penalty** from ==**1 lakh to one crore rupees**==
##### Where Voluntary liquidation process -> initiated with intent to defraud
- AA -> impose penalty ==one lakh to one crore rupees==
##### Where any person initiationes PPIRP WITH INTENT TO DEFRAUD OR FOR purpose other than resolution of insolvency
- Penalty ==**1lakh to one crore**==

<br>

#### Fraudulent or wrongful trading
- Business carried out of the CD with ==**intent to defraud Creditors of CD**== -> AA upon **application by [[#Resolution professional]] -> pass an order that ==persons who were knowingly parties to such business== shall be ==liable to make such contributions ot the assets fo the creditor as deemed fit==**

<br>

#### Fraudulent management of CD dduring PPIRP
- where -> ==**officer of the CD**==  manages its affairs with the ==**intent to defraud creditors of the CD or for any fraudulent purpose**== -> AA may on an application by RP pass an ==order **imposing a penalty of 1 lakh to 1 crore rupees on such officer**==





---
### OFFENCES AND PENALTIES (68-77A)\
#### For wilful concealement of property, debt due to CD (of 10k or more), or fraudulent removal of property fo CD of value 10k or more, or falsification of any book or paper relating to the proeprty of same vlaue within 12 montsh immediately preceding the Insolvency commencement date
- Imprisonment ==**at least three years**== to 5 years
- or with fine of ==**1lakh to one crore**== or
- both

#### Punishment for transactions defrauding creditors 
- on after insolvency commencement date, if an officer of the CD or the CD
	1. made or caused to be made any gift or transfer of, or charge on, or has caused or connived in the execution of a decree or order against, the property of the corporate debtor
	2. <mark style="background: #FF5582A6;">concealed or removed any part of the property of the corporate debtor within two months before the date of any unsatisfied judgment, decree or order for payment of money obtained against the corporate debtor</mark> , such officer of the corporate debtor or the corporate debtor
	Punishable with **==imprisonment for at least a year but may extend to 5==**; or with **==fine==** of 1 lakh to one crore


#### Falsification of books on and after the insolvency commencement date
- Imprisonment of ==**at least 3 years**== but **not more than 5 years
- or **Fine** of at least **==one lakh==** but **not more than one crore**
- or both 

#### Misconduct in course of CIRP
###### What qualifies as misconduct by the CD
- Where **an officer of the CD** -> **on or after [[#Initiation date and insolvency commencement date|insolvency commencement date]] 
	1. **does not disclose the Rp all details of the property** of the CD and details of the transaction or other requiried information
	2.  d**oes not deliver to the resolution professional all or part of the property of the corporate debtor in his control or custody and which he is required to delive**r
	3.  **does not deliver to the resolution professiona**l ==**all books and papers in his control or custody belonging to the corporate debtor**== and which he is required to deliver
	4. **fails** to **inform the RP** the ==information of his knowledge that a debt has been falsely proved by any person during the CIRP==
	5. ==**prevents the production of any book or paper affecting or relating to the property or affairs**== of the corporate debtor
	6. 
		- **==accounts for any part of the property of the corporate debtor by fictitious losses==** or expenses, or
		- if he **has so attempted at any meeting of the creditors of the corporate debtor within the twelve months immediately preceding the insolvency commencement date**,
##### Punishment
- Imprisonment for ==**not less than 3 years**== but which may extend to 5 years
- find of **==at least one lakh== but may extend to ==one core==** 
- or both

#### False representation to creditors - s73
##### When does it happen?
- Where any officer of the CD
	1. ==**on or after the insolvency commencement date**== -> makes a **false representation or commits any fraud** -> for the **prupose fo obtaining consent fo the creditors of the CD** to an ==**agreement with reference to the affairs of the CD**== -> <mark style="background: #FF5582A6;">during the CIRP or the Liquidation process</mark> 
	2. **prior** to teh **==insolvency commencment date==** -> he has ==**made anyfalse representation**==, or **committed any fraud** for **obtaining the consent of the creds for such agreement**

#### Contravention of Moratorium or the resolution - s74
##### Where the CD or any of its officers knowingly or wilfully authorised committed or committed such contravention?
- Imprisonment not less than 3 years but may extend to 5
- or fine **not less than one lakh extending to 3 lakh**
- or both
##### Creditor violates s14, or any person knowingly or wilfully authorised or permitted such contravention by a creditor?
- imprisonment ==**one to 5 years**==
- fine from **==one lakh to one crore==**
##### CD or any of its officers or creditors or any person to whom the Resolution plan is binding under s31 knowing or wilfully contravenes terms ofsuch plan orabets such contravention?
- Such person 
	- prision ==one year to 5==
	- fin -> ==1lakh to on crore== or both

<br>


#### Where falso information is made under section 7 (application by financial info) where it is false in material particulars/omits any material flact knowing it to be material - s75
- Fine ==one lakh to on crore==

![[Day 1  IBC-2.png]]


<br>


#### Punishment -> non disclosure of dispute or payment of debt by operational creditor - section 76
- if Operational creditor **wilfully or knowingly concealed** in application under <mark style="background: #00FFFE73;">section 9</mark>  
	1. that the **CD** had **notified him of a dispute in respect of the unpaid debt**
		- or the **full and final payment of the operational debt
	1. or any person who **knowingly and wilfully authorised or permitted such concealment**
	such creditor or person

	-> (1) imprisonment of r term **of ==one year to 5==** or with (2) **fine of ==1L to 1 cr==** or both

![[Day 1  IBC-3.png]]
<br>

#### Punishment -> false information by corporate debtor under s10 - section 77
- 
	- info that is **false in material particulars** knowing that they were false ==**and**== **omits any material fact** knowing it to be material or
	- any person knowingly/wilfully authorised or permitted the furnishing of such info 
- -> such CD or person 
	1. imprisonment -> ==**3 years to 5 years**== or
	2. ==fine== **one lakh to 1 crore**
	3. or both

![[Day 1  IBC-4.png]]
<br>

<br>


#### Punishment -> offence r/ating to PPIRP - s77A

^75c6d1

- wHERE
	1. cd PROVIDES INFO UNDER S54c WHICH IS **false in material particulars**; knowing it to be false or
	2. **omits any material fact** *knowing it to be material*
	3. CD provides -> information in the **list of claims or the preliminaryinformation memorandum** which is ==**false in material particulars** knowing it to be false or omits nay material fact knwoing it to be material==
	4. any person **knowiingly or wilfulyy** authorised or permitted the furnishing of such info under points 1 and 2 (subcluases a and b under the Act)
- pUNISHMENT : ==prison for 3 to 5 years== or with ==fine 1L to 1 crore== or ==both==


<br>

- Where **director or partner of Cd** ==deeliberately contravenes provisions of CH III A==
	1. prison ==3 -5 years==
	2. fine -> ==1 L to 1 crore== 

---
