---
home: true
link: https://www.notion.so/IBC-Repository-f76d478068ef4ca1a4a2c7c5a331fb6f
notionID: f76d4780-68ef-4ca1-a4a2-c7c5a331fb6f
up:: [[🎯 INTERNSHIP DASHBOARD]]
banner_icon: 📚

embedded-title: false

---
# IBC Repository
Website:: https://insolvency-and-bankruptcy.markbase.xyz/

<br>


```toc
```

---

## Summary of the Act
1. **[[Parts I and II of IBC|Part I]]**
2. **[[Part III IBC|Part 2]]**



---
## Rules
1. [[The Insolvency and Bankruptcy (Application to Adjudicating Authority) Rules, 2016]] #complete 
2. [[The Insolvency and Bankruptcy (pre-packaged insolvency resolution process) Rules, 2021]] #complete 
3. [[The Insolvency and Bankruptcy (Insolvency and Liquidation Proceedings of Financial Service Providers and Application to Adjudicating Authority) Rules, 2019]]
4. [[Insolvency and Bankruptcy (Application to Adjudicating Authority for Bankruptcy Process for Personal Guarantors to Corporate Debtors) Rules, 2019.]]
5. [[The Insolvency and Bankruptcy (Application to Adjudicating Authority for Bankruptcy Process for Personal Guarantors to Corporate Guarantors) Rules, 2019]]
6. [[The Insolvency and Bankruptcy (Application to Adjudicating Authority for Insolvency Resolution Process for Personal Guarantors to Corporate Debtors) Rules, 2019]] #complete 






----
## Regulations
> [!note]
> 
> - The IBBI has the power to make regulations wrt the COde
> 


<br>


1. [[IBBI (Information Utilities) Regulations, 2017 (Amended upto 14.06.2022)]]
2. [[IBBI (Inspection and Investigation) Regulations, 2017 (amended upto 14.06.2022)]]
3. [[IBBI (Grievance and Complaint Handling Procedure) Regulations, 2017 (amended upto 14.06.2022)]]
4. [[ IBBI (Insolvency Resolution Process for Corporate Persons) Regulations, 2016 (Amended upto 14.06.2022)]]
5. [[IBBI (Liquidation Process) Regulations, 2016 (Amended upto 28.04.2022)]]
6. [[IBBI (Voluntary Liquidation Process) Regulations, 2017 (Amended upto 05.04.2022)]]
7. [[IBBI (Model Bye-Laws and Governing Board of Insolvency Professional Agencies) Regulations, 2016 (Amended upto 22.07.2021)]]
8. [[IBBI (Insolvency Professionals) Regulations, 2016 (Amended upto 22.07.2021)]]
9. [[IBBI (Pre-packaged Insolvency Resolution Process) Regulations, 2021]] #inprogress 
10. [[IBBI (Insolvency Resolution Process for Personal Guarantors to Corporate Debtors) Regulations, 2019]]
11. [[IBBI (Bankruptcy Process for Personal Guarantors to Corporate Debtors) Regulations, 2019]]
12. [[IBBI (Procedure for Governing Board Meetings) Regulations, 2017 (Amended upto 23.07.2019)]]
13. [[IBBI (Insolvency Professional Agencies) Regulations, 2016 (Amended upto 23.07.2019)]]
14. [[IBBI (Mechanism for Issuing Regulations) Regulations, 2018]]
15. [[IBBI (Fast Track Insolvency Resolution Process for Corporate Persons) Regulations, 2017 (Amended upto 07.02.2018)]]



----
## Reports
1. [[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan]] #complete 



---
## Articles
1. [[Personal Guarantors Under The Insolvency And Bankruptcy Code, 2016 – The Road Ahead - Insolvency, Bankruptcy - India]]
2. [[Operational Creditors - Tale of Disenfranchisement]]
3. [[Between The Lines | NCLAT - Nil payment to operational creditors is permissible under the resolution plan]]


<br>


