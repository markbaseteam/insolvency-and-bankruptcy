---
up:: [[📚 IBC Repository]]
---
# 📝 Bankruptcy Law Reforms Committee Report under Dr TK Vishwanathan (Summary of Important portions)
```toc
```


<br>

---
## Executive summary
### Problem
- The report says that **creditors have for long had low power when faced with default**; promoters **stay in control of the ocmpany even after default**
	- under the framework at the time, **secured credit gave right to banks**; however, the problem was that some of the most important creditors were not banks; rather, they were the *"dispersed mass of households and financial firsm who buy [[corporate bonds]]"*; however, the **bond holder did not have enough power**
		- this led to **low recovery rates** which meant that **lenders were averse to lending**

---

### Opinion of the report on IRP
- While in some cases, **liquidation is the answer**, in amny sitatuion, the ==**firm can be protected as a goiong concern**==; 
	- when this happens, the ==**costs imposed upon society goes down**== ; why?  because **liquidation involves the destruction of the organisational capital of the firm**

<br>

#### Opinion of committee on who should be able to file for IRP?
- Under the companies act, only the following parties could file an application before the NCLT for a declaration that the company is sick?
	1. the **company**
	2. any **==secured creditor==**
	3. the Central govt
	4. RBI
	5. State govt
	6. **public financial institution**
	7. State level institution
	8. a Scheduled bank
- **OPINION OF COMMITTEE**
	- that ==**any creditor whether financial or operational should be able to initiate the IRP proposed under the code**==

<br>

#### Proposed strategy of the Committee
- When a **default takes pplace**, an **Insolvency resolution process cna be initiated** 
	- the duration should be **180 days**
	- the IRP was to be overseen by an ==**insolvency professional**== who was 
		1. to ensure that the **assets are not stolen from the company**; 
		2. to initiate a **careful check of the trnasaction fo the copmany** fo rht prev 2 years and 
		3. look for ==**illegal diversion of assets**== -> such diversions **should exact criminal charges**

<br>

#### Calm period 
- During this period, the **creditors should stay their claims** ; why?, because ==**this gives a better chance for th efirm to survive as a going concern**==
	- company propsed that ==**75% fo the creditors should agree on the revival plan**== (this has been changed to <mark style="background: #00FFFE73;">66%</mark> )
		- if in limited circumstances, 75% *no 66* percent of the creditors **decides that the complexity of the case requires ore time** for the filing of the plan, a **one time extension of 90 days may be granted**
	- <mark style="background: #00FF3E8C;">Rationale: at this point, the **debtor was permitted to seek extensions beyondany time limit**</mark> 
- CALm period will also **assure the debtor and creditors of a time-bound and level field in their negotiations to assess viability**

<br>

#### On liquidation
- TO happen when 
	- coc **decides quickly that the right path is liquidation**
	- 180 days lapse and **no one plan is able to obtain the majority required**
- Liquidation to be carried out by a **regulated insolvency professional** -> the **liquidator**
	- assets of the company **to be held in trust** 
	- **==rights of [[Parts I and II of IBC#Secured creditor 3 30|secured creditors]]==**  -> they have the choice of **taking their collateral and selling on their own** 
- Position of Central and state govt in the **distribution of waterfall**  will be **below that of unsecured financial creditors**
	- object: to **promote availability of [[credit]] and <mark style="background: #00FF3E8C;">develop a market for unsecured credit financing</mark> **


<br>

#### Bankruptcy and insolvency of persons
##### Fresh Start
- In this case, ==**specified cases**, loans of a **limited class of borrowers** can be **waived**==



<br>

#### Object of information Utilities under the Report
- For IRP to begin -> parties need an **accurate and undisputed set of facts** about *existing credit, collateral that has been pledged, etfc*
	- when parties seek to obtain this info, it can **lead to considerable loss of time**
- keeping in mind the ==**180 day limit**==, -> **proposal of [[information utility (IBC)|information utilities]]** -> will help in **preventing delay**
- Function: ==**when IRP begins, within less than a day -> these will give undisputed and complete info to all persons in the IRP and thus address the source of delay**==

##### Who to regulate IUs?
- The **procedural details** regarding the functioning of IUs should **not be encoded in primary law**; why? -> because they will need to evolve based on the experience and changes in the economy rapidly -> thus ==**these regulations should be drafted by a regulator**==



---
## Economic Thinking
### Role of Insolvency in debt financing
- Need for Insolvency process -> creditors put money into debt investments today; however,  the **returns expected on these investments -> uncertain**
	![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan.png]]

<br>

#### Assessing viability?
##### When is an enterprise facing financial failure considered vialbe?
- When there is a ==**possible financial rearrangement that can earn the creditors a higher economic value than shutting down the enterprise**==
- It is considered <mark style="background: #FF0000A3;">**unviable**</mark>  when the **cost of the arrangement requiried to keep the enterprise going** will be **higher than the Net Positive Value or NPV of future cash flows***

##### When can conflicts arise in creditor debtor negotiation?
- Reasons:
	1. **assymetry fo information** b/w the **creditor and debtor**
		- debtor having more info about the enterprise <u>will tend to have the upper-hand in the negotiation</u>
	1. creditor has incentive to **close out their investment quickly** i order to **avail alternative investment opportunities** ⭐

##### Possible achievements of a sound bankruptcy law?
1. it can **improve handling of conflicts** between creditors and debtors such that it can **reduce problems of common property and information asymmetry for all economic participants**
2. Many firms possess **useful [[organisational capital]]**; -> if the parties were to opt for **restructuring of liabilities** and passing on the the management to a **new management** and the firm to a **new set of owners**, this [[organisational capital]] can be protected

<br>

#### Goals of Bankruptcy law
1. TO **prevent illegitimate transfer of wealth out of companies by controlling shareholders**; this can be carried out **in anticipation of the company approaching default** 
2. Not all defaults should be equated with malfeasance as **this would hamper risk taking**
3. Bankruptcy law must **seek to devise swift mechanisms for ==shifting control of company  to creditors upon default of debt==**


----
### Diffulties of the arrangemnt existing at the time?
- Companies Act contained provisions for rescue and rehabilitation of all registered entities in CH XIX; this was not notifeid at time of report; the law for rescue and rehabilitation was the **SIck Industrial Companies Act of 1985** 
- The legal framework for **bankruptcy resolution of winding up of companies** was the CA act as the provisions of the CA 2013 were not yet notified

<br>

- This process for firms was **==hgihly fragmented==** as the **powers of the creditor and debor**  were provided under different Acts
	- **efficiency of resolution of conflicts between creditors and debtors -> low as the rights were separately defined**
	- furthermore, **these different laws are implemented in different judicial fora**
- There is **==lack of clarity of jurisdiction==**; **one forum decides rights of creditor while other the rigths of the debto**; these decisions are appealsed and either stayed or overturned in a a higher court
	- however, ***if economic value is to be preserved, there must be a single forum that hears both sides of the cae and makes a judgement based on both***

>ALl in all -> environment of **judicial and legislative uncertainty led to poor outcomes on insolvency and bankruptcy** 

>Summary
> ![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan-1.png]]

---
### Principles of Code
1. **Early assessment** of the **viability of the enterprise**
2. The **final decision wrt viability of the enterprise** -> has to be an ==**agreement among creditors who are the financers willing to bear the loss in insolvency**==
3. <mark style="background: #FF5582A6;">**Legislature and the Courts** must **not make business decisions</mark> ; however, they must control the process of resolution
4. There **must be a calm period** within which the ==**debtor can negotiate int eh assessment of viabiity** ***without the fear of debt recovery enforcement by creditors***==
5. Law must appoint a ==**resolution professional**== whoo will be the **manager of the resoluution period** so that **creditors can negotiate the assessment of viability ==with confidence that the debtors will not take any action to erode the value fo the enterprise==**
6. The Code -> to **enable information symmetry between creditors and debtors** -> must ensure the access of this info to **all the creditors to the enterprise**, directly indirectly or through the resolution professional
7. Time bound process -> to **better preserve economic value**
8. ⭐ <mark style="background: #FF4E00A6;">The law must order the liquidation of an enterprise which has been found unviable. This outcome of the negotiations should be protected against all appeals other than for very exceptional cases.</mark> 
9. All the provisions relating to existing law dealing with **insolvency or registered entities** will be ==**removed and replaced by this Code**==
	- this will allow higher legal clarity when there arises any question of insolvency or bankruptcy
1. **==Both debtor and creditor==** **must have the ability to ==trigger insolvency==**
2. [[information utility (IBC)]] -> to **make available all relevant information to all stakeholders in resolving insolvency and bankruptcy**

---
####  Need for regulatied industry of Insolvency professions
- IPs -> to be delegated the task of **monitoring an managing matters of business** by the adjudicating authority
	- this will ensure **both debtors and creditors that** <mark style="background: #00FF3E8C;">the **econmic value** is not **eroded by the actions taken by the other</mark> 

#### regulation making powers
- to be **granted to the Insolvency and Bankruptcy Board of India** 2

<br>


#### Resolution in case of Bankruptcy
![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan-2.png]]


----
## Institutional Infrastructure
- IBBI to be set up as statutory body

### Insolvency Regulator
#### Need for IBBI (regulator)
- FOr creating rules of procedure and modifying them 
- for **creating a database ==about the working of every bankruptcy and insolvency transaction in the country==** which will include **case histories of every transaction** and the **working of each insolvency professional**
	- this -> to address **pervasive lack of information of histrocal cases**; 

<br>

##### Proposed regulated industries:
1. [[information utility (IBC)]]
2. and **Insolvency professionals and agencies**

<br>

#### Objectives of the IBBI
- To utilise its functions legislative executive and quasi judicial in order to ==**acheive a well-functioning bankruptcy process in India**== -> which will be characterised by
	1. **high [[recovery rates]]** in an NPV sense
	2. **low delays** from teh start to the end


<br>

#### Executive functions of IBBI
1. Inspections
2. Investigations
3. enforcement of   orders and processing complaints

>Excecutive and legislative functions must not overlap

<br>


#### Quasi Judicial functions
- Regulators need to assess whether or not regulated entities have complied with the provisions of the law
	- in case of **detected breach**,  -> appropriate penalties must be imposed

#### Appeals against Actions of Regulator
- Appeals fro the Board's order -> **should lie before the NCLAT** 
	- an **aggrieved party** (NCLAT's order) -> **statutory right to appeal to the ==supreme Court==**

![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan-3.png]]

#### Obtianing resources and spending them
- Board **should fund itself** from eh **fees collected form its regulated entities**
	- however, the industry of regulated professionals and entities will develop only over time; thus committee recommended that Board be funded through mix of govt support fees collected from regulated industries for the first five years after it comes into being

<br>

<br>


<br>


### Bankruptcy and Insolvency Adjudicator
#### Tribunals
- Companies Act and LLP Act 2008 -> confers jurisdiction to NCLT for <u>winding up and liquidation</u> and <u>dissolution an winding of of companies and llps respectively</u> ; committee recommended that this arrangement be continued
##### With regard to Individual insolvency and bankruptcy
- <mark style="background: #FF0000A3;">Committee felt that the Indian laws in existence at the time are archaic</mark>  when it came to **jurisdiction on individual insolvency and bankruptcy** as **==individual insolvency is not treated at par with corporate insolvency==**
- 
	- Committe opined that the <mark style="background: #00FF3E8C;">goals of insolvency an liquidation of firms overlaps with goals of banikruptcy laws for individuals</mark> 

###### With regard to physical infrastructure of Adjudication instituions for Individual insolvency
- Committee felt that **this needs to be more widespread** across the country so as to **facilitate access to justice for the common Indian** 
	- since DRT has **far wider presence across the country**, the committee recommended that the ==**DRT should be vested with jurisdiction over individual insolvency and bankruptcy matters**==

##### With regard to Jurisdiction on insolvency regulator
- Code establishes the Board for **regulating IPs, IPAs, and IUs**
	- regulator **may have ==administrative law wing to perform <u>quasi judicial functions of the regulator</u>==** 

<br>

##### Territorial Jurisdiction
- Current Indian law on Corp bankruptcy at that time caused **confusion on territorial jurisdiction**; *NCLT and DRT's jurisdiction could be based on **place where cause of action arose** or the **location of the debtor**-* 
	- Under companies Act -> location of the registered office of the Debtor determined the jurisdiction
	- However, under the Recovery of Debts due to Banks and financial institutions Act and the Securitisation and Reconstruction fo Financial Assets and Enforcement of Security Interest Act, 2002, the DRT within whose jurisdiction CoA arises wholly or in part **may also have jurisdiction** 
		- Since a part of the cause of action arises at the location of the bank branch where the loan transaction had taken place, the DRT which has jurisdiction over the bank branch is an eligible forum for an original application by the bank. 
	- This led to much **cross litigation and conflicting order by the company court and the DR**

    
	>- TO avoid this confusion, -> committee recommended that the jurisdiction of the NCLT should be determined **according to the location of the registered office of the debtor**
	>	- and that of DRT -> must be determined according to the **place where the debtor actually and voluntarily resides or carries on business or personally works for gain**

- Recommended that the **jurisdiction of the civil court should be barred where either of these 2 has jurisdiction**

<br>


<br>

### Bankruptcy and insolvency information utilities
![[information utility (IBC)]]

- The board will license and regulate the working of the IUs;

#### Information requriements for Insolvency and bankruptcy resolution 
1. Reliable and readily accessible
2. clear evidence fo the instance of default
3. recores of assets that are pledged as collateral against secured credit contracts
4. reliable and readily accessible recoreds that ocmprise the balance sheet and cash flow statements of the entity

#### Information about the liabilites of a solvent entity
- Existence of all financial contracts along with terms and conditions -> relevant for all financial analysis relating to the health and status fo the entity
- While mandatory dislcosure and noncompliance requirements did not workk, in this case **the Code specifies that if the Adjudicator is able to locate the record of the liability and of the default with the registeredk, IUs, then a [[financial creditor]] needs no other proof to establish proof of default**; (this is an incentive)

##### Framework of Record to be included in IUs  regarding financial liabilities
1. Centralised databases about the **full set of liabilities of all entities** that are **entered into by financial firms**
2. Public disclosure norms about liabilities; will depend on if they are **listed securities or not**
	1. If listed -> public disclosure of **terms and conditions of the contracts**; 
	2. if **the entity does not have even one listed security** -> access to the terms and conditions of the contracts -> in a **limited manner**

##### Record of operational liabilities
- During state of insolvency -> record of **all liabilities in the IUs -> critical to operational creditors in assessing the complexity of resolution required**
- Difficulties exist in **implementing an efficient mechanism** to enable creditors to **trigger resolution process**; -> committee considered one approach --> ==presentation of an **undisputed invoice demanding payment** or **notice delivered by such creditor to the debtor as a document** as **joint proof of an existing liability and default by thedebtor of this liabilitY**==
###### Requirement of debtor who is filing for insolvency resolution
- He must **file a ==comprehensive list of all operational liabilities over the previous two years into a registered IU==** 

<br>


#### Addresing gap in existing infra -> lack of info about default
- Committe: to draw upon the transmission of cash flows to securities holders to prove the event of default
	- committee: a **single elecontric mechanism should exist through which all cash flows to the holders of their securities are transmitted**
		- this would **prevent possibility of issues of securities who selectively default on payments to powerful investors while reneging on less powerful investors** #doubt 
	- When a **default occurs**, it becomes a **failure of transmission of the promised cash flow into the account**; this can be forwarded to the **IU** by the depository;

#### Info about secured assets
- Since lenders w/ secured assets are **most likely to want to retrieve thier security** and **carry out debt recovery themselves in  order to minimise costs of liquidation**, the committee opined that ==**secured lenders will be incentivised to ensure that accurate info is filed under the IU**==

<br>


<br>

### Insolvency Professionals
- TO hold following roles
	1. **==Resolution professional==**
	2. Bankrutpcy trustee in an individual bankruptcy process
	3. Liquidator in a firm liquidation process
- To require **License**

#### IP agencies
- To be formed accoreding to the guidelines laid out by the board
- Committee recommends that these agencies **establish rules and standards for their members through bye-laws**  and have mechanisms to enforce their rules and standards
- IP agencies **to only issue by laws**; this should be overseen by the board
- IP agencies have to assess whether or not an IP has complied with provisions of the bye laws; **in case of dtected breach -> the agency has the power to impose appropriate penalties** -> thus ==**IP agency to have independent quasi judicial wing**==

----
## Process for legal entities
- Calm period for negotiations; in this period, **insolvency professionals to mange the entity and the assets under supervision of the AA**
- AA to **ensure adherence to the process** 
- Business decisions to be taken by **==committee of financial creditors==** 
	- debtor -> non voting member; invited to all meetings
- Where creditors don't agree within prescribed time -> ==**liquidation**==
	- when liquidation happens, the <mark style="background: #FF4E00A6;">board of the entity is replaced by the creditors committee</mark> 
- Creditors may w/ ~~75%~~ now 66% vote -> apply to the AA for a **single extension of another 90 days**
- Committee: RP to **have the power to run the entity as a going concern** in order to ==**assure the creditors that the assets of the entity will be protected**==


<br>

- **CoC** to **<u>coprise only of financial creditors</u>**
	- why?; because according to the committee -> members of CoC should have 
		1. **capability** to **assess viability**, and
		2. be **willing to modify terms of the existing liabilities in negotiations**
	- normally -> operational creditors are **nota able to decide on matters regarding the insovlency of the entity** and are <mark style="background: #FF0000A3;">**not willing to take the risk of posponing payments for better future prospects of the entity**</mark> 
- IUs to readily aid i **identification of all financial creditors**

<br>

### Committee did not prescribe how the insolvency is to be resolved
- Committee felt that **types of possible solutions** are **specific to the time and environment in which the insolvency becomes visible**
- It felt that freedom should be permitted to the overall market to propose solution on keeping the entity as a going concern
- Thus **no restrictions in the code on possible ways in which the business model for the entity or its financial model or both can be changed** in order to keep the entity as going concern

> - The committee argued that **==there must be a counterbalance to operational creditors not having a vote on the creditors committee==**
> 	- thus, opined: <mark style="background: #00FF3E8C;">dues of the operational creditors **must have priority in being paid as an explicit part of the proposed solution**</mark>  

<br>


### Rules to close IRP
1. Either Resolution professional is ==able to get a binding agreement of majority of the credits committee==
	- in this case, IRP closes
2. Or the calm period reaches the **==default maximym date==** set by the adjudicator
	- in this case, IRP is ordered to be closed and **and order to liquidate the entity is passed**

<br>

### Fast-track IRP
- Committee saw merit in ***creating explicit provisions for cases where the IRP is to be carried out in shorter time periods than complex cases***
	- Most entities are **likely to have a less complex structure**

<br>

### Liquidation
1. Only assets that are **owned by the entity** as it **was in place before the IRP** -> available for liquidation
2. The entity will ==**lose beneficial ownership on the assets**==; the ownership -> **moved to a ==liquidation trust==** and the **liquidator manages the trust**
3. Secured creditors -> can **choose to enforce their security interst after the liquidation order is passed**
4. <mark style="background: #FF5582A6;">Members of **Limited libaility firm** are **not liable for its dues**</mark> 
5. Foreign creditors treated on part with domestic creditors
#### When liquidation can be triggered
1. Rejection of resolution plan by the adjudicator -> upon **failure to meet the necessary conditions**
2. Failure to **reach agreement in the COC** during the stipulated period
3. BY **decision of Committee of Creditors**
4. By **failure of adherence to terms of Resolution plan**

#### Steps at start of liquidation
1. **Creation of trust for the assets of the entity**
	- trust created -> it becomes the **owner of the assets of the entity** -> trust will **distribute the dividents as per the payout provisions of the Code**
	- trust to be managed by [[Parts I and II of IBC#Resolution professional|resolution professional]]

#### When Appeals can be entertained against the outcome?
- When there is **evidence of ==fraud== or ==material irregularity==**


#### Realisation in liquidation other than through sale of assets
- Distinction between business and the entity
	- business and entity are different -> business is the **underlying structure whose operations generate revenue**; the entity **incudes the management, ownerhsip and the financial elements around this core business**
##### Difference between liquidation and IRP when it comes to defining what is the best solutino
1. In ==**IRP**== -. the **financia creditors** have the **power to ==choose the best solution==** provided that the **liabilites of the other creditors will be fully met**
2. iN **==Liquidation==**, -> <mark style="background: #00FF3E8C;">secured creditors will have the best recovery</mark>  while other creditors **financial and operational** will face a lower recovery

<br>

#### Recoveries from vulnerable transactions
- Transactions -> a) **fraudulent transfeers** and b) **fraudulently prferring certain creditor or class of creditors** -> these transactions are **liable to be reversed**

<br>

#### Establishing priority of payout in Liquidation
![[📝 Bankruptcy Law Reforms Comittee Report under Dr TK Vishwanathan-4.png]]


<br>

#### Fees of Liquidator
- To be paid out to creditors **net of the insolvency resolution and Liquidator costs**


<br>

#### At end of liquidation
- Complete dissolution
- If the AA does not rule in favour of the applicaiton, the **liquidation case remains open**
---
## Process for individuals

### Applicability of the COde
1. Sole propriteros where the **lgal personality of the proprietorship is not different from the individual who owns it**
2. Personal Guarantors
3. Consumer finance borrowers
4. Student loan borrowers
5. Credit card borrowers
6. Farmers
7. Micro-Finance borrowers
8. Partnership firms

<br>

### Types of processes

#### Fresh Start Order
- Process by which **individuals with assets and income lower than specified amounts** -> will be eligible for a ==**discharge from their qualifying debts**== 

#### Insolvency Resolution Process
- **negotiation between debtors and creditors** <- to be supervised by a [[Part III IBC#Resolution professional|Resolution professional]]
- If <mark style="background: #00FF3E8C;">Negotiation succeeds</mark>  -> then there is **[[Part III IBC#Repayment Plan|Repayment Plan]]**
- If negotiations **<mark style="background: #FF0000A3;">FAIL</mark>** 🔴, then the **==bankruptcy process is initiated==**  🟥
	- here, the **bankrupty trustee is appointed by the AA** 


<br>

### Triggering insolvency

#### Fresh Start Order 
- Debtors who have **assets and income below this specified level** -> given FSO
- ==**Only the debtor can file for an FSO**==

#### Insolvency Resolution Process
- Can be initiated by **both teh ==debtor and the creditor==**
	- IRP -> **cannot be made for debts excluded by the RP**

##### Process for Triggering Insolvency by debtor
- Debtor has **more information about the entity** than the fcrditor; therefore, a **debtor's application ==must include inforationas so as to reduce the aymmetry that creditor has in evaluting insolvenfcy==**
- Contents of application:
	1. List of all debts - **secured and unsecured owed by the debtor** on the dat eof application
	2. **amount of debt** secured and unsecured
	3. **names of creditors to whom each debt is owed**
	4. Details of **securityor collateral** held in respect of any debts
	5. Other financial info wrt assets and cash flow status fo the debtor for upto two years prior to application date
- Debtor to sign ==**Statement of truth**== -> to be held **liabole if information in application is found to be fraudulent or deliberately hidden**

##### Process of triggering insolvency by crditor
> [!important]
> - Committee voted to **exclude the clause which said that *creditors could invoke insolvency proceedings if there was a 'reasonable prosepect'* of the inability to pay debts** -> why? because this could be a device used to **harrass crditors**

- **CONTENTS OF APPLICATON**
	1. EVIDEnce of **default on payjments** filed with the [[Parts I and II of IBC#Information Utility|information utility]]
		- if **evidence is NOT PRESENT with information utility 🔴**, the **creditor will have to ==provide other releveant evidence fo default==**

##### Effect of filing an application (AA)
- Not possible to asdcerain veracity and validity of applicaion 


<br>

#### Moratorium period
- Goal -> ensure **suspension of debt collection actions by creditors**
	- Creditor will ==**will not have any remedy in respect of the debt**==

#### Preparation of Repayment plan during the moratorium period
##### Who makes the plan? 
- Debtor in **consultation with the [[Part III IBC#Resolution professional|Resolution Professional]]**
- Proposal shoul dinclude **not only the balance sheet of the individual** but also the ==**details of how the debtor proposes to repay creditors**==
	- should also provide **reasons why the creditors may accept the plan**

#### Code to allow for replacement of resolution professional
- In order to **act as a deterrent against bad behaviour**


<br>

### Bankruptcy Application
- Committee: filure of IRP **does not automatically lead to bnkruptcy**; it ==**only makes it possible for either the debtor or the creditor to make a separate appliction for bankruptcy**==
	- this is because acc to the committee -> there should be **greater effort towards ==possibiliity of voluntary negotiations== such that personal assetws of the debtor remain with him to the extent possible**

#### Effect of Bankruptcy Order 
- The ==**estate of the bankrupt**== will ==**vest with the Trustee**== and will become **divisable among the creditors**

